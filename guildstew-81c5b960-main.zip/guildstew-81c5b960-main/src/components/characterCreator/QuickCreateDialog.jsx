
import React, { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Sparkles, ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { AnimatePresence, motion } from "framer-motion";
import { getLanguagesForCharacter } from "@/components/dnd5e/backgroundData";
import { 
  calculateMaxHP, 
  calculateAC, 
  calculateProficiencyBonus, 
  calculatePassivePerception,
  getSpeed,
  calculateAbilityModifier
} from "@/components/dnd5e/characterCalculations";

const races = ["Dragonborn", "Elf", "Dwarf", "Human", "Halfling", "Tiefling", "Half-Elf", "Half-Orc", "Gnome"];
const classes = ["Barbarian", "Bard", "Cleric", "Druid", "Fighter", "Monk", "Paladin", "Ranger", "Rogue", "Sorcerer", "Warlock", "Wizard"];
const backgrounds = ["Acolyte", "Charlatan", "Criminal", "Entertainer", "Folk Hero", "Guild Artisan", "Hermit", "Noble", "Outlander", "Sage", "Sailor", "Soldier", "Urchin"];

export default function QuickCreateDialog({ open, onClose, onCharacterCreated }) {
  const [mode, setMode] = useState('initial'); // initial, quick, ai
  const [generating, setGenerating] = useState(false);
  
  // Quick pick state
  const [name, setName] = useState("");
  const [selectedRace, setSelectedRace] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedBackground, setSelectedBackground] = useState("");
  
  // AI generate state
  const [description, setDescription] = useState("");

  const handleQuickPick = () => {
    if (!name || !selectedRace || !selectedClass || !selectedBackground) {
      toast.error("Please fill in all fields");
      return;
    }

    const defaultAttributes = { str: 10, dex: 10, con: 10, int: 10, wis: 10, cha: 10 };
    const level = 1;
    const proficiencyBonus = calculateProficiencyBonus(level);
    const maxHP = calculateMaxHP(selectedClass, level, defaultAttributes.con);

    const character = {
      name,
      race: selectedRace,
      class: selectedClass,
      background: selectedBackground,
      level: 1,
      alignment: "True Neutral",
      attributes: defaultAttributes,
      skills: {},
      spells: { cantrips: [], level1: [] },
      proficiency_bonus: proficiencyBonus,
      hit_points: { max: maxHP, current: maxHP, temporary: 0 },
      armor_class: calculateAC(defaultAttributes.dex),
      initiative: calculateAbilityModifier(defaultAttributes.dex),
      speed: getSpeed(selectedRace),
      passive_perception: 10,
      languages: getLanguagesForCharacter(selectedRace, selectedBackground)
    };

    onCharacterCreated(character);
    handleClose();
  };

  const handleAIGenerate = async () => {
    if (!description.trim()) {
      toast.error("Please provide a character description");
      return;
    }

    setGenerating(true);
    try {
      const prompt = `Create a D&D 5e level 1 character based on: "${description}"

Available races: ${races.join(', ')}
Available classes: ${classes.join(', ')}
Available backgrounds: ${backgrounds.join(', ')}

Generate a character with:
- Name, race, class, background, alignment
- Ability scores (str, dex, con, int, wis, cha) between 8-15
- 2-4 appropriate skills set to true
- A backstory
- Physical appearance details

Keep it simple and valid.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            race: { type: "string" },
            class: { type: "string" },
            background: { type: "string" },
            alignment: { type: "string" },
            attributes: { 
              type: "object",
              properties: {
                str: { type: "number" },
                dex: { type: "number" },
                con: { type: "number" },
                int: { type: "number" },
                wis: { type: "number" },
                cha: { type: "number" }
              },
              required: ["str", "dex", "con", "int", "wis", "cha"]
            },
            skills: { type: "object" },
            description: { type: "string" },
            appearance: { 
              type: "object",
              properties: {
                age: { type: "number" },
                height: { type: "string" },
                weight: { type: "string" }
              }
            }
          },
          required: ["name", "race", "class", "background", "attributes", "alignment"]
        }
      });

      const proficiencyBonus = calculateProficiencyBonus(1);
      const maxHP = calculateMaxHP(result.class, 1, result.attributes.con);
      const ac = calculateAC(result.attributes.dex);
      const initiative = calculateAbilityModifier(result.attributes.dex);
      const speed = getSpeed(result.race);

      const perceptionMod = calculateAbilityModifier(result.attributes.wis);
      const isPerceptionProficient = result.skills?.["Perception"] || false;
      
      let passivePerception = 10 + perceptionMod;
      if (isPerceptionProficient) {
        passivePerception += proficiencyBonus;
      }

      const finalCharacter = {
        name: result.name,
        race: result.race,
        subrace: result.subrace || "",
        class: result.class,
        subclass: "",
        background: result.background,
        alignment: result.alignment,
        level: 1,
        attributes: result.attributes,
        skills: result.skills || {},
        expertise: [],
        spells: { cantrips: [], level1: [] },
        languages: getLanguagesForCharacter(result.race, result.background),
        feature_choices: {},
        equipment: { weapons: [], armor: {} },
        inventory: [],
        personality: { traits: [], ideals: "", bonds: "", flaws: "" },
        description: result.description || "",
        companion_name: "",
        companion_background: "",
        appearance: result.appearance || {},
        proficiency_bonus: proficiencyBonus,
        hit_points: { max: maxHP, current: maxHP, temporary: 0 },
        armor_class: ac,
        initiative: initiative,
        speed: speed,
        passive_perception: passivePerception
      };

      onCharacterCreated(finalCharacter);
      handleClose();
      toast.success("Character created with AI!");
    } catch (error) {
      console.error("AI Generation Error:", error);
      const errorMessage = error?.message || "Unknown error";
      toast.error(`Failed to generate: ${errorMessage}. Try Quick Pick instead.`);
    } finally {
      setGenerating(false);
    }
  };

  const handleClose = () => {
    setMode('initial');
    setName("");
    setSelectedRace("");
    setSelectedClass("");
    setSelectedBackground("");
    setDescription("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-[#1E2430] border-[#2A3441] max-w-2xl">
        <AnimatePresence mode="wait">
          {mode === 'initial' && (
            <motion.div
              key="initial"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-3xl font-bold text-white mb-2">Quick Create</h2>
                <p className="text-white/60">Choose how you want to create your character</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => setMode('quick')}
                  className="bg-[#2A3441] hover:bg-[#2A3441]/80 rounded-xl p-6 border-2 border-[#37F2D1]/30 hover:border-[#37F2D1] transition-all text-left"
                >
                  <div className="text-3xl mb-3">⚡</div>
                  <h3 className="text-xl font-bold text-white mb-2">Quick Pick</h3>
                  <p className="text-white/60 text-sm">Choose race, class, and background manually</p>
                </button>

                <button
                  onClick={() => setMode('ai')}
                  className="bg-[#2A3441] hover:bg-[#2A3441]/80 rounded-xl p-6 border-2 border-[#FF5722]/30 hover:border-[#FF5722] transition-all text-left"
                >
                  <div className="text-3xl mb-3">✨</div>
                  <h3 className="text-xl font-bold text-white mb-2">AI Generate</h3>
                  <p className="text-white/60 text-sm">Describe your character and let AI create everything</p>
                </button>
              </div>
            </motion.div>
          )}

          {mode === 'quick' && (
            <motion.div
              key="quick"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <Button
                onClick={() => setMode('initial')}
                variant="ghost"
                className="text-white/60 hover:text-white mb-2"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>

              <h2 className="text-2xl font-bold text-white">Quick Pick Character</h2>

              <div className="space-y-4">
                <div>
                  <Label className="text-white mb-2 block">Character Name</Label>
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter name..."
                    className="bg-[#2A3441] border-[#37F2D1]/20 text-white"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Race</Label>
                  <Select value={selectedRace} onValueChange={setSelectedRace}>
                    <SelectTrigger className="bg-[#2A3441] border-[#37F2D1]/20 text-white">
                      <SelectValue placeholder="Select race" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1E2430] border-[#2A3441]">
                      {races.map(race => (
                        <SelectItem key={race} value={race} className="text-white hover:bg-[#2A3441]">
                          {race}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Class</Label>
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger className="bg-[#2A3441] border-[#37F2D1]/20 text-white">
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1E2430] border-[#2A3441]">
                      {classes.map(cls => (
                        <SelectItem key={cls} value={cls} className="text-white hover:bg-[#2A3441]">
                          {cls}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Background</Label>
                  <Select value={selectedBackground} onValueChange={setSelectedBackground}>
                    <SelectTrigger className="bg-[#2A3441] border-[#37F2D1]/20 text-white">
                      <SelectValue placeholder="Select background" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1E2430] border-[#2A3441]">
                      {backgrounds.map(bg => (
                        <SelectItem key={bg} value={bg} className="text-white hover:bg-[#2A3441]">
                          {bg}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleQuickPick}
                  className="w-full bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430] font-bold"
                >
                  Create Character
                </Button>
              </div>
            </motion.div>
          )}

          {mode === 'ai' && (
            <motion.div
              key="ai"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <Button
                onClick={() => setMode('initial')}
                variant="ghost"
                className="text-white/60 hover:text-white mb-2"
                disabled={generating}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>

              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-[#FF5722]" />
                AI Character Generator
              </h2>

              <p className="text-white/60 text-sm">
                Describe your character concept and AI will create a complete character with all choices made including subclass, spells, skills, equipment, and even companions!
              </p>

              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Example: A wise elven cleric who serves the goddess of life and travels the land healing the sick. She has a gentle demeanor but is fierce in battle..."
                className="bg-[#2A3441] border-[#FF5722]/20 text-white min-h-32"
                disabled={generating}
              />

              <Button
                onClick={handleAIGenerate}
                disabled={generating || !description.trim()}
                className="w-full bg-gradient-to-r from-[#FF5722] to-[#FF6B3D] hover:from-[#FF6B3D] hover:to-[#FF5722] text-white font-bold"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Character
                  </>
                )}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
