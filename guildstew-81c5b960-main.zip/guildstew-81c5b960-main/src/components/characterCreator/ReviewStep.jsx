
import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { User } from "lucide-react";
import { getClassFeaturesForLevel } from "@/components/dnd5e/classFeatures";
import { spellDetails } from "@/components/dnd5e/spellData";

const classes = [
  { name: "Barbarian", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/a6652f2d8_Barbarian1.png", description: "Fierce warriors who draw upon primal rage in battle, with unmatched physical prowess." },
  { name: "Bard", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/cbe7f7dba_Bard1.png", description: "Versatile performers who use music and magic to inspire allies and hinder foes." },
  { name: "Cleric", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/15fe6ef24_Cleric1.png", description: "Divine spellcasters who serve the gods and channel holy power, combining potent spellcasting with combat ability." },
  { name: "Druid", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/ef43c9ff2_Druid1.png", description: "Nature-focused spellcasters who can transform into animals and control the battlefield." },
  { name: "Fighter", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/5e1b2cd68_Fighter1.png", description: "Masters of martial combat and weaponry with unparalleled weapon training." },
  { name: "Monk", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/f2e85e13a_Monk1.png", description: "Martial artists who harness ki energy to perform supernatural feats." },
  { name: "Paladin", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/1eb7cd2f2_Paladin1.png", description: "Holy warriors bound by sacred oaths who combine divine magic with martial prowess." },
  { name: "Ranger", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/748e5be38_Ranger1.png", description: "Skilled hunters and wilderness warriors who combine martial prowess with nature magic." },
  { name: "Rogue", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/a66f2aac1_Rogue1.png", description: "Stealthy tricksters who strike from the shadows with deadly precision." },
  { name: "Sorcerer", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/6f5b501db_Sorceror1.png", description: "Natural spellcasters born with innate magical power who can manipulate spells using Metamagic." },
  { name: "Warlock", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/184c98268_Warlock1.png", description: "Gain power through a pact with a powerful otherworldly being, with reliable magical attacks." },
  { name: "Wizard", icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/94cfaa28a_Wizard1.png", description: "Scholarly spellcasters who master arcane magic through study, with the largest spell list." }
];

const raceTraits = {
  "Dragonborn": [
    { name: "Breath Weapon", description: "Use your action to exhale destructive energy based on your draconic ancestry." },
    { name: "Damage Resistance", description: "Resistance to damage type associated with your draconic ancestry." },
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." }
  ],
  "Elf": [
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." },
    { name: "Fey Ancestry", description: "Advantage on saves against being charmed, magic can't put you to sleep." },
    { name: "Trance", description: "Elves don't sleep, instead meditate for 4 hours." }
  ],
  "Dwarf": [
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." },
    { name: "Dwarven Resilience", description: "Advantage on saves against poison and resistance to poison damage." },
    { name: "Stonecunning", description: "Double proficiency on History checks related to stonework." }
  ],
  "Human": [
    { name: "Versatile", description: "+1 to all ability scores." },
    { name: "Extra Skill", description: "Proficiency in one additional skill." }
  ],
  "Halfling": [
    { name: "Lucky", description: "Reroll 1s on attack rolls, ability checks, or saving throws." },
    { name: "Brave", description: "Advantage on saves against being frightened." },
    { name: "Nimble", description: "Move through space of larger creatures." }
  ],
  "Tiefling": [
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." },
    { name: "Hellish Resistance", description: "Resistance to fire damage." },
    { name: "Infernal Legacy", description: "Know thaumaturgy cantrip, hellish rebuke at 3rd level." }
  ],
  "Half-Elf": [
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." },
    { name: "Fey Ancestry", description: "Advantage on saves against being charmed, magic can't put you to sleep." },
    { name: "Skill Versatility", description: "Proficiency in two skills of your choice." }
  ],
  "Half-Orc": [
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." },
    { name: "Relentless Endurance", description: "When reduced to 0 HP, drop to 1 HP instead (once per long rest)." },
    { name: "Savage Attacks", description: "Roll extra weapon damage die on critical hits." }
  ],
  "Gnome": [
    { name: "Darkvision", description: "See in dim light within 60 feet as if it were bright light." },
    { name: "Gnome Cunning", description: "Advantage on Int, Wis, and Cha saves against magic." },
    { name: "Small Size", description: "Between 3-4 feet tall with unique advantages." }
  ]
};

const dragonbornBreathWeapons = {
  "Gold": { type: "Fire", shape: "15ft cone" },
  "Silver": { type: "Cold", shape: "15ft cone" },
  "Bronze": { type: "Lightning", shape: "5ft x 30ft line" },
  "Copper": { type: "Acid", shape: "5ft x 30ft line" },
  "Brass": { type: "Fire", shape: "5ft x 30ft line" },
  "Red": { type: "Fire", shape: "15ft cone" },
  "Blue": { type: "Lightning", shape: "5ft x 30ft line" },
  "Green": { type: "Poison", shape: "15ft cone" },
  "Black": { type: "Acid", shape: "5ft x 30ft line" },
  "White": { type: "Cold", shape: "15ft cone" }
};

const skillDescriptions = {
  "Acrobatics": "Balance, tumbling, rolls, and fancy footwork",
  "Animal Handling": "Calming, training, and controlling animals",
  "Arcana": "Knowledge of magic, spells, and magical items",
  "Athletics": "Climbing, jumping, swimming, and physical feats",
  "Deception": "Lying convincingly and misleading others",
  "History": "Knowledge of historical events and ancient lore",
  "Insight": "Reading people's emotions and detecting lies",
  "Intimidation": "Influencing others through threats and fear",
  "Investigation": "Finding clues and making logical deductions",
  "Medicine": "Treating injuries, illnesses, and poison",
  "Nature": "Knowledge of plants, animals, and weather",
  "Perception": "Noticing details in your surroundings",
  "Performance": "Acting, dancing, singing, and public displays",
  "Persuasion": "Convincing others diplomatically",
  "Religion": "Knowledge of gods, rituals, and faiths",
  "Sleight of Hand": "Pickpocketing and manual dexterity tricks",
  "Stealth": "Moving quietly and hiding from others",
  "Survival": "Tracking, hunting, and wilderness navigation"
};

const backgroundDescriptions = {
  "Acolyte": "You have spent your life in service to a temple, learning sacred rites and providing sacrifices to the god or gods you worship.",
  "Charlatan": "You have always had a way with people. You know what makes them tick and can tease out their hearts' desires after a few minutes of conversation.",
  "Criminal": "You are an experienced criminal with a history of breaking the law.",
  "Entertainer": "You thrive in front of an audience. You know how to entrance them, entertain them, and inspire them.",
  "Folk Hero": "You come from humble social rank, but you are destined for so much more.",
  "Guild Artisan": "You are a member of an artisan's guild, skilled in a particular field.",
  "Hermit": "You lived in seclusion for a formative part of your life.",
  "Noble": "You understand wealth, power, and privilege.",
  "Outlander": "You grew up in the wilds, far from civilization.",
  "Sage": "You spent years learning the lore of the multiverse.",
  "Sailor": "You sailed on a seagoing vessel for years.",
  "Soldier": "War has been your life for as long as you care to remember.",
  "Urchin": "You grew up on the streets alone, orphaned, and poor."
};

const alignmentDescriptions = {
  "Lawful Good": "Believes in honor, compassion, and helping others while respecting laws and order.",
  "Neutral Good": "Does good because it's right, regardless of laws.",
  "Chaotic Good": "Values freedom and kindness above all.",
  "Lawful Neutral": "Values order, tradition, and law above all else.",
  "True Neutral": "Balanced and pragmatic, acts based on situation.",
  "Chaotic Neutral": "Values personal freedom above all.",
  "Lawful Evil": "Uses laws and systems to gain power and hurt others.",
  "Neutral Evil": "Purely selfish and does whatever benefits them.",
  "Chaotic Evil": "Destroys and causes suffering for pleasure."
};

const companionTypes = {
  Paladin: "Mount",
  Ranger: "Animal Companion",
  Warlock: "Patron",
  Wizard: "Familiar",
  Druid: "Animal Companion"
};

export default function ReviewStep({ characterData }) {
  const [hoveredItem, setHoveredItem] = useState(null);

  const calculateModifier = (score) => {
    const mod = Math.floor((score - 10) / 2);
    return mod >= 0 ? `+${mod}` : `${mod}`;
  };

  const getModifierColor = (modifier) => {
    if (modifier.startsWith('+')) return 'text-[#37F2D1]';
    if (modifier.startsWith('-')) return 'text-[#F23737]';
    return 'text-white';
  };

  const profBonus = Math.floor((characterData.level - 1) / 4) + 2;
  const conMod = Math.floor((characterData.attributes.con - 10) / 2);
  const maxHP = 10 + conMod;
  const ac = 10 + Math.floor((characterData.attributes.dex - 10) / 2);

  const primaryClassLevel = characterData.level - (characterData.multiclasses || []).reduce((sum, mc) => sum + (mc.level || 0), 0);
  const primaryFeatures = getClassFeaturesForLevel(characterData.class, primaryClassLevel) || [];
  const multiclassFeatures = (characterData.multiclasses || []).flatMap(mc => {
    if (!mc.class || !mc.level) return [];
    const features = getClassFeaturesForLevel(mc.class, mc.level) || [];
    return features.map(f => ({ ...f, multiclass: mc.class }));
  });
  const allClassFeatures = [...primaryFeatures, ...multiclassFeatures];

  const profileImageUrl = characterData.profile_avatar_url || characterData.avatar_url;
  const profilePosition = characterData.profile_position || { x: 0, y: 0 };
  const profileZoom = characterData.profile_zoom || 1;

  const primaryClassIcon = classes.find(c => c.name === characterData.class)?.icon;
  const primaryClassDesc = classes.find(c => c.name === characterData.class)?.description;
  const raceFeatures = raceTraits[characterData.race] || [];

  const companionName = companionTypes[characterData.class];

  const isDragonborn = characterData.race === "Dragonborn";
  const breathWeaponInfo = isDragonborn && characterData.subrace ? dragonbornBreathWeapons[characterData.subrace] : null;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-[#1E2430] mb-2">Character Overview</h2>
        <p className="text-[#1E2430] font-semibold">Review your character before finalizing</p>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left Column - Portrait */}
        <div className="space-y-4">
          <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
            <div className="w-40 h-40 rounded-full bg-[#1E2430] overflow-hidden border-4 border-[#FF5722] mx-auto mb-4 relative">
              {profileImageUrl ? (
                <img
                  src={profileImageUrl}
                  alt="Character Portrait"
                  className="absolute"
                  style={{
                    transform: `translate(${profilePosition.x}px, ${profilePosition.y}px) scale(${profileZoom})`,
                    transformOrigin: 'center center',
                    width: '100%',
                    height: '100%',
                    objectFit: 'contain',
                    pointerEvents: 'none'
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <User className="w-16 h-16 text-gray-500" />
                </div>
              )}
            </div>
            <h3 className="text-2xl font-bold text-[#FFC6AA] text-center mb-1">
              {characterData.name || "Unnamed Character"}
            </h3>
            <p className="text-center text-white">
              Level {characterData.level} {characterData.race} {characterData.class}
            </p>
            {characterData.multiclasses && characterData.multiclasses.filter(mc => mc.class).length > 0 && (
              <div className="mt-2 text-center">
                {characterData.multiclasses.filter(mc => mc.class).map((mc, idx) => (
                  <p key={idx} className="text-sm text-[#5B4B9E]">
                    {mc.class} {mc.level}
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* Class Icons */}
          <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
            <h3 className="text-lg font-bold text-[#FFC6AA] mb-3">Classes</h3>
            <div className="space-y-3">
              {primaryClassIcon && (
                <div 
                  className="flex items-center gap-3 relative cursor-help"
                  onMouseEnter={() => setHoveredItem('primary-class')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <img src={primaryClassIcon} alt={characterData.class} className="w-16 h-16" />
                  <div>
                    <p className="font-bold text-[#5B4B9E]">{characterData.class}</p>
                    <p className="text-white text-sm">Level {primaryClassLevel}</p>
                  </div>
                  {hoveredItem === 'primary-class' && primaryClassDesc && (
                    <div className="absolute z-10 left-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#5B4B9E]">
                      {primaryClassDesc}
                    </div>
                  )}
                </div>
              )}
              {(characterData.multiclasses || []).filter(mc => mc.class).map((mc, idx) => {
                const mcIcon = classes.find(c => c.name === mc.class)?.icon;
                const mcDesc = classes.find(c => c.name === mc.class)?.description;
                return (
                  <div 
                    key={idx} 
                    className="flex items-center gap-3 relative cursor-help"
                    onMouseEnter={() => setHoveredItem(`mc-class-${idx}`)}
                    onMouseLeave={() => setHoveredItem(null)}
                  >
                    {mcIcon && <img src={mcIcon} alt={mc.class} className="w-16 h-16" />}
                    <div>
                      <p className="font-bold text-[#5B4B9E]">{mc.class}</p>
                      <p className="text-white text-sm">Level {mc.level}</p>
                    </div>
                    {hoveredItem === `mc-class-${idx}` && mcDesc && (
                      <div className="absolute z-10 left-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#5B4B9E]">
                        {mcDesc}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Racial Features */}
          {raceFeatures.length > 0 && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-3">Racial Traits</h3>
              <div className="space-y-2">
                {raceFeatures.map((trait, idx) => {
                  const isBreathWeapon = isDragonborn && trait.name === "Breath Weapon";
                  const isDamageResist = isDragonborn && trait.name === "Damage Resistance";
                  
                  return (
                    <div
                      key={idx}
                      className="relative cursor-help p-3 bg-[#1E2430] rounded-lg"
                      onMouseEnter={() => setHoveredItem(`racetrait-${idx}`)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <p className="font-semibold text-white text-sm">
                        {trait.name}
                        {isBreathWeapon && breathWeaponInfo && (
                          <span className="text-[#37F2D1] ml-2">({breathWeaponInfo.type})</span>
                        )}
                        {isDamageResist && breathWeaponInfo && (
                          <span className="text-[#37F2D1] ml-2">({breathWeaponInfo.type})</span>
                        )}
                      </p>
                      {hoveredItem === `racetrait-${idx}` && (
                        <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                          <div className="font-bold mb-1">{trait.name}</div>
                          {trait.description}
                          {isBreathWeapon && breathWeaponInfo && (
                            <div className="mt-2 pt-2 border-t border-white/20">
                              <div className="text-[#37F2D1] font-bold">Your Breath Weapon:</div>
                              <div>Type: {breathWeaponInfo.type}</div>
                              <div>Shape: {breathWeaponInfo.shape}</div>
                            </div>
                          )}
                          {isDamageResist && breathWeaponInfo && (
                            <div className="mt-2 pt-2 border-t border-white/20">
                              <div className="text-[#37F2D1] font-bold">Your Resistance:</div>
                              <div>{breathWeaponInfo.type} damage</div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Combat Stats */}
          <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
            <h3 className="text-lg font-bold text-[#FFC6AA] mb-3">Combat Stats</h3>
            <div className="space-y-2 text-sm">
              <div
                className="flex justify-between relative cursor-help"
                onMouseEnter={() => setHoveredItem('hp')}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <span className="text-[#FFC6AA]">Hit Points:</span>
                <span className="text-white font-semibold">{maxHP}</span>
                {hoveredItem === 'hp' && (
                  <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                    Your maximum HP determines how much damage you can take before falling unconscious.
                  </div>
                )}
              </div>
              <div
                className="flex justify-between relative cursor-help"
                onMouseEnter={() => setHoveredItem('ac')}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <span className="text-[#FFC6AA]">Armor Class:</span>
                <span className="text-white font-semibold">{ac}</span>
                {hoveredItem === 'ac' && (
                  <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                    Your AC determines how hard you are to hit in combat. Higher is better.
                  </div>
                )}
              </div>
              <div
                className="flex justify-between relative cursor-help"
                onMouseEnter={() => setHoveredItem('prof')}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <span className="text-[#FFC6AA]">Proficiency Bonus:</span>
                <span className="text-[#37F2D1] font-semibold">+{profBonus}</span>
                {hoveredItem === 'prof' && (
                  <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#37F2D1]">
                    Added to attacks, skills, and saves you're proficient in. Increases with level.
                  </div>
                )}
              </div>
              <div
                className="flex justify-between relative cursor-help"
                onMouseEnter={() => setHoveredItem('speed')}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <span className="text-[#FFC6AA]">Speed:</span>
                <span className="text-white font-semibold">{characterData.speed || 30} ft</span>
                {hoveredItem === 'speed' && (
                  <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                    How far you can move in a single turn during combat.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Character Details */}
          <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
            <h3 className="text-lg font-bold text-[#FFC6AA] mb-4">Character Details</h3>
            <div className="space-y-2 text-sm">
              <div 
                className="relative cursor-help"
                onMouseEnter={() => setHoveredItem('background')}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <span className="text-[#FFC6AA]">Background:</span>
                <span className="text-white font-semibold ml-2">
                  {characterData.background || "Not set"}
                </span>
                {hoveredItem === 'background' && characterData.background && backgroundDescriptions[characterData.background] && (
                  <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                    {backgroundDescriptions[characterData.background]}
                  </div>
                )}
              </div>
              <div 
                className="relative cursor-help"
                onMouseEnter={() => setHoveredItem('alignment')}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <span className="text-[#FFC6AA]">Alignment:</span>
                <span className="text-white font-semibold ml-2">{characterData.alignment}</span>
                {hoveredItem === 'alignment' && alignmentDescriptions[characterData.alignment] && (
                  <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                    {alignmentDescriptions[characterData.alignment]}
                  </div>
                )}
              </div>
              {characterData.subrace && (
                <div>
                  <span className="text-[#FFC6AA]">Subrace:</span>
                  <span className="text-white font-semibold ml-2">{characterData.subrace}</span>
                </div>
              )}
              {characterData.appearance?.age && (
                <div>
                  <span className="text-[#FFC6AA]">Age:</span>
                  <span className="text-white font-semibold ml-2">{characterData.appearance.age}</span>
                </div>
              )}
              {characterData.appearance?.height && (
                <div>
                  <span className="text-[#FFC6AA]">Height:</span>
                  <span className="text-white font-semibold ml-2">{characterData.appearance.height}</span>
                </div>
              )}
              {characterData.appearance?.weight && (
                <div>
                  <span className="text-[#FFC6AA]">Weight:</span>
                  <span className="text-white font-semibold ml-2">{characterData.appearance.weight}</span>
                </div>
              )}
            </div>
          </div>

          {/* Companion/Familiar */}
          {companionName && characterData.companion_image && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#5B4B9E]">
              <h3 className="text-lg font-bold text-[#5B4B9E] mb-3">{companionName}</h3>
              <div className="w-full aspect-square rounded-lg bg-[#1E2430] overflow-hidden border-2 border-[#5B4B9E] mb-3">
                <img
                  src={characterData.companion_image}
                  alt={companionName}
                  className="w-full h-full object-cover"
                />
              </div>
              {characterData.companion_name && (
                <p className="text-white font-semibold mb-2">{characterData.companion_name}</p>
              )}
              {characterData.companion_background && (
                <p className="text-sm text-gray-300 leading-relaxed">{characterData.companion_background}</p>
              )}
            </div>
          )}
        </div>

        {/* Middle Column - Abilities & Skills */}
        <div className="space-y-4">
          <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
            <h3 className="text-lg font-bold text-[#FFC6AA] mb-4">Ability Scores</h3>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(characterData.attributes).map(([key, value]) => {
                const modifier = calculateModifier(value);
                const abilityNames = { str: "Strength", dex: "Dexterity", con: "Constitution", int: "Intelligence", wis: "Wisdom", cha: "Charisma" };
                const abilityDescriptions = {
                  str: "Physical power for melee attacks and carrying",
                  dex: "Agility for ranged attacks, AC, and stealth",
                  con: "Health and stamina for HP and concentration",
                  int: "Reasoning for knowledge and investigation",
                  wis: "Awareness for perception and insight",
                  cha: "Personality for persuasion and spellcasting"
                };
                return (
                  <div
                    key={key}
                    className="text-center p-3 bg-[#1E2430] rounded-lg relative cursor-help"
                    onMouseEnter={() => setHoveredItem(key)}
                    onMouseLeave={() => setHoveredItem(null)}
                  >
                    <div className="text-xs text-white uppercase mb-1">{key}</div>
                    <div className={`text-2xl font-bold ${getModifierColor(modifier)}`}>{modifier}</div>
                    <div className="text-sm text-gray-400">{value}</div>
                    {hoveredItem === key && (
                      <div className="absolute z-10 left-1/2 -translate-x-1/2 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-48 shadow-lg border-2 border-[#FF5722]">
                        <div className="font-bold mb-1">{abilityNames[key]}</div>
                        {abilityDescriptions[key]}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
            <h3 className="text-lg font-bold text-[#FFC6AA] mb-4">Skills</h3>
            <div className="flex flex-wrap gap-2">
              {Object.entries(characterData.skills || {})
                .filter(([_, proficient]) => proficient)
                .map(([skill]) => {
                  const hasExpertise = (characterData.expertise || []).includes(skill);
                  return (
                    <div
                      key={skill}
                      className="relative cursor-help"
                      onMouseEnter={() => setHoveredItem(`skill-${skill}`)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <Badge className={hasExpertise ? "bg-yellow-400 text-[#1E2430]" : "bg-[#37F2D1] text-[#1E2430]"}>
                        {skill} {hasExpertise && "★"}
                      </Badge>
                      {hoveredItem === `skill-${skill}` && (
                        <div className="absolute z-10 left-1/2 -translate-x-1/2 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-48 shadow-lg border-2 border-[#37F2D1]">
                          <div className="font-bold mb-1">{skill}</div>
                          {skillDescriptions[skill]}
                          {hasExpertise && <div className="mt-2 text-yellow-400 font-bold">★ Expertise: Double proficiency bonus</div>}
                        </div>
                      )}
                    </div>
                  );
                })}
              {Object.keys(characterData.skills || {}).filter(k => characterData.skills[k]).length === 0 && (
                <span className="text-gray-400 text-sm">No skills selected</span>
              )}
            </div>
          </div>

          {allClassFeatures.length > 0 && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-4">Class Features</h3>
              <div className="space-y-2">
                {allClassFeatures.map((feature, idx) => (
                  <div
                    key={idx}
                    className="relative cursor-help p-3 bg-[#1E2430] rounded-lg"
                    onMouseEnter={() => setHoveredItem(`classfeature-${idx}`)}
                    onMouseLeave={() => setHoveredItem(null)}
                  >
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-white text-sm">{feature.name}</span>
                      {feature.multiclass && (
                        <Badge className="bg-[#5B4B9E] text-white text-xs">
                          {feature.multiclass}
                        </Badge>
                      )}
                      {feature.level && (
                        <Badge className="bg-[#1E2430] text-gray-300 border border-white/20 text-xs">
                          Lvl {feature.level}
                        </Badge>
                      )}
                    </div>
                    {hoveredItem === `classfeature-${idx}` && feature.description && (
                      <div className="absolute z-10 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-80 shadow-lg border-2 border-[#5B4B9E] max-h-48 overflow-y-auto">
                        <div className="font-bold mb-1">{feature.name}</div>
                        {feature.description}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {characterData.inventory && characterData.inventory.length > 0 && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-4">Equipment</h3>
              <div className="space-y-1 text-sm text-white">
                {characterData.inventory.slice(0, 8).map((item, idx) => (
                  <div key={idx}>
                    • {item.name} {item.quantity > 1 ? `(×${item.quantity})` : ''}
                  </div>
                ))}
                {characterData.inventory.length > 8 && (
                  <div className="text-gray-400 text-xs mt-2">
                    +{characterData.inventory.length - 8} more items
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Column - Details */}
        <div className="space-y-4">
          {characterData.spells && (characterData.spells.cantrips?.length > 0 || characterData.spells.level1?.length > 0) && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-4">Spells</h3>
              
              {characterData.spells.cantrips && characterData.spells.cantrips.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-[#5B4B9E] mb-2">Cantrips</h4>
                  <div className="flex flex-wrap gap-2">
                    {characterData.spells.cantrips.map((spell, idx) => {
                      const spellInfo = spellDetails[spell];
                      return (
                        <div
                          key={idx}
                          className="relative cursor-help"
                          onMouseEnter={() => setHoveredItem(`cantrip-${idx}`)}
                          onMouseLeave={() => setHoveredItem(null)}
                        >
                          <Badge className="bg-[#5B4B9E] text-white">
                            {spell}
                          </Badge>
                          {hoveredItem === `cantrip-${idx}` && spellInfo && (
                            <div className="absolute z-10 left-1/2 -translate-x-1/2 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#5B4B9E] max-h-64 overflow-y-auto">
                              <div className="font-bold mb-1">{spell}</div>
                              <div className="text-[#5B4B9E] text-xs mb-2">
                                {spellInfo.level} {spellInfo.school}
                              </div>
                              <div className="space-y-1 mb-2 text-xs">
                                <div><span className="text-white/60">Casting Time:</span> {spellInfo.castingTime}</div>
                                <div><span className="text-white/60">Range:</span> {spellInfo.range}</div>
                                <div><span className="text-white/60">Components:</span> {spellInfo.components}</div>
                                <div><span className="text-white/60">Duration:</span> {spellInfo.duration}</div>
                              </div>
                              <p className="text-white/80 leading-relaxed">{spellInfo.description}</p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {characterData.spells.level1 && characterData.spells.level1.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-[#5B4B9E] mb-2">1st Level Spells</h4>
                  <div className="flex flex-wrap gap-2">
                    {characterData.spells.level1.map((spell, idx) => {
                      const spellInfo = spellDetails[spell];
                      return (
                        <div
                          key={idx}
                          className="relative cursor-help"
                          onMouseEnter={() => setHoveredItem(`spell1-${idx}`)}
                          onMouseLeave={() => setHoveredItem(null)}
                        >
                          <Badge className="bg-[#37F2D1] text-[#1E2430]">
                            {spell}
                          </Badge>
                          {hoveredItem === `spell1-${idx}` && spellInfo && (
                            <div className="absolute z-10 left-1/2 -translate-x-1/2 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#37F2D1] max-h-64 overflow-y-auto">
                              <div className="font-bold mb-1">{spell}</div>
                              <div className="text-[#37F2D1] text-xs mb-2">
                                {spellInfo.level} {spellInfo.school}
                              </div>
                              <div className="space-y-1 mb-2 text-xs">
                                <div><span className="text-white/60">Casting Time:</span> {spellInfo.castingTime}</div>
                                <div><span className="text-white/60">Range:</span> {spellInfo.range}</div>
                                <div><span className="text-white/60">Components:</span> {spellInfo.components}</div>
                                <div><span className="text-white/60">Duration:</span> {spellInfo.duration}</div>
                              </div>
                              <p className="text-white/80 leading-relaxed">{spellInfo.description}</p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {characterData.description && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-3">Biography</h3>
              <p className="text-sm text-white leading-relaxed">{characterData.description}</p>
            </div>
          )}

          {characterData.languages && characterData.languages.length > 0 && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-3">Languages</h3>
              <div className="flex flex-wrap gap-2">
                {characterData.languages.map((lang, idx) => (
                  <Badge key={idx} variant="secondary" className="bg-[#1E2430] text-white">
                    {lang}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {characterData.feature_choices && Object.keys(characterData.feature_choices).length > 0 && (
            <div className="bg-[#2A3441] rounded-xl p-6 border-2 border-[#1E2430]">
              <h3 className="text-lg font-bold text-[#FFC6AA] mb-3">Feature Choices</h3>
              <div className="space-y-2 text-sm text-white">
                {Object.entries(characterData.feature_choices).map(([key, choice], idx) => {
                  const featureName = key.split('-').pop();
                  return (
                    <div key={idx}>
                      <span className="text-[#5B4B9E] font-semibold">{featureName}:</span>
                      <span className="ml-2">{choice}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
