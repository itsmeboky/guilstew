
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { spellsByClass, recommendedSpells, spellDetails, effectDescriptions, getSpellSlots, getAllAvailableSpells } from "@/components/dnd5e/spellData";

export default function SpellsStep({ characterData, updateCharacterData }) {
  const [hoveredEffect, setHoveredEffect] = useState(null);
  const [showRecommendation, setShowRecommendation] = useState(false);
  
  const spellSlots = getSpellSlots(characterData.class, characterData.level, characterData.multiclasses || []);
  const availableSpells = getAllAvailableSpells(characterData.class, characterData.multiclasses || []);
  
  const selectedCantrips = characterData.spells?.cantrips || [];
  const selectedLevel1 = characterData.spells?.level1 || [];

  // Determine which class provides spellcasting
  const getSpellcastingClass = () => {
    const spellcastingClasses = ["Bard", "Cleric", "Druid", "Sorcerer", "Wizard", "Warlock"];
    const halfCasters = ["Paladin", "Ranger"];
    
    // Check primary class first
    if (spellcastingClasses.includes(characterData.class)) {
      return { class: characterData.class, level: characterData.level };
    }
    
    if (halfCasters.includes(characterData.class) && characterData.level >= 2) {
      return { class: characterData.class, level: characterData.level };
    }
    
    // Check multiclasses
    for (const mc of (characterData.multiclasses || [])) {
      if (spellcastingClasses.includes(mc.class)) {
        return { class: mc.class, level: mc.level };
      }
      if (halfCasters.includes(mc.class) && mc.level >= 2) {
        return { class: mc.class, level: mc.level };
      }
    }
    
    return null;
  };

  const spellcastingClass = getSpellcastingClass();

  if (spellSlots.cantrips === 0 && spellSlots.level1 === 0) {
    return (
      <div className="max-w-4xl mx-auto text-center py-12 bg-[#2A3441] rounded-xl p-8 border-2 border-[#1E2430]">
        <h2 className="text-2xl font-bold text-[#FFC6AA] mb-4">No Spells Available</h2>
        <p className="text-white">
          {characterData.class} at level {characterData.level} doesn't have spellcasting yet.
        </p>
      </div>
    );
  }

  const handleCantripToggle = (spell, checked) => {
    const newCantrips = checked
      ? [...selectedCantrips, spell]
      : selectedCantrips.filter(s => s !== spell);
    
    updateCharacterData({
      spells: { ...characterData.spells, cantrips: newCantrips }
    });
  };

  const handleLevel1Toggle = (spell, checked) => {
    const newLevel1 = checked
      ? [...selectedLevel1, spell]
      : selectedLevel1.filter(s => s !== spell);
    
    updateCharacterData({
      spells: { ...characterData.spells, level1: newLevel1 }
    });
  };

  const useRecommended = () => {
    // Find the first class that has recommendations
    let recommended = null;
    let recommendedClass = null;
    
    // Check primary class
    if (recommendedSpells[characterData.class]) {
      recommended = recommendedSpells[characterData.class];
      recommendedClass = characterData.class;
    } else {
      // Check multiclasses
      for (const mc of (characterData.multiclasses || [])) {
        if (recommendedSpells[mc.class]) {
          recommended = recommendedSpells[mc.class];
          recommendedClass = mc.class;
          break;
        }
      }
    }
    
    if (recommended) {
      updateCharacterData({
        spells: {
          cantrips: recommended.cantrips.slice(0, spellSlots.cantrips),
          level1: recommended.level1.slice(0, spellSlots.level1)
        }
      });
      setShowRecommendation(recommendedClass);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="bg-[#2A3441] rounded-xl p-6 mb-6 border-2 border-[#1E2430]">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-2xl font-bold text-[#FFC6AA] mb-3">Spellcasting</h2>
            <p className="text-white mb-2">
              {spellcastingClass ? (
                <>
                  As a level {spellcastingClass.level} <span className="text-[#5B4B9E] font-bold">{spellcastingClass.class}</span>, you can prepare the following spells:
                </>
              ) : (
                <>As a level {characterData.level} {characterData.class}, you can prepare the following spells:</>
              )}
            </p>
            <div className="flex gap-4 text-sm">
              {spellSlots.cantrips > 0 && (
                <div className="text-[#37F2D1]">
                  <span className="font-bold">Cantrips:</span> {selectedCantrips.length}/{spellSlots.cantrips}
                </div>
              )}
              {spellSlots.level1 > 0 && (
                <div className="text-[#37F2D1]">
                  <span className="font-bold">1st Level:</span> {selectedLevel1.length}/{spellSlots.level1}
                </div>
              )}
            </div>
          </div>
          <Button
            onClick={useRecommended}
            className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Use Recommended
          </Button>
        </div>
      </div>

      {showRecommendation && recommendedSpells[showRecommendation] && (
        <div className="bg-[#2A3441] border-2 border-[#37F2D1] rounded-xl p-4 mb-6">
          <h3 className="text-[#37F2D1] font-bold text-lg mb-2">Recommended Spells for {showRecommendation}</h3>
          <p className="text-white">{recommendedSpells[showRecommendation].reasoning}</p>
        </div>
      )}

      {spellSlots.cantrips > 0 && (
        <div className="mb-8">
          <h3 className="text-xl font-bold text-[#5B4B9E] mb-4">Cantrips</h3>
          <div className="grid grid-cols-2 gap-4">
            {availableSpells.cantrips.map((spell) => {
              const details = spellDetails[spell] || {
                level: "Cantrip",
                school: "Various",
                castingTime: "1 action",
                range: "Varies",
                components: "V, S",
                duration: "Instantaneous",
                description: "A magical cantrip.",
                effects: []
              };
              const isSelected = selectedCantrips.includes(spell);
              const isDisabled = !isSelected && selectedCantrips.length >= spellSlots.cantrips;

              return (
                <div
                  key={spell}
                  onClick={() => !isDisabled && handleCantripToggle(spell, !isSelected)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#2A3441] border-[#37F2D1] border-4'
                      : 'bg-[#2A3441] border-[#1E2430]'
                  } ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-[#37F2D1]/50'}`}
                >
                  <div className="flex items-start gap-3 mb-2">
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={(checked) => handleCantripToggle(spell, checked)}
                      disabled={isDisabled}
                      className="mt-1 border-white pointer-events-none"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-[#FFC6AA]">{spell}</h4>
                      <div className="text-xs text-gray-400 mb-2">
                        {details.school} • {details.castingTime} • {details.range}
                      </div>
                      <p className="text-xs text-white leading-relaxed">{details.description}</p>
                      {details.effects && details.effects.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {details.effects.map((effect, idx) => (
                            <div
                              key={idx}
                              className="relative"
                              onMouseEnter={() => setHoveredEffect(effect)}
                              onMouseLeave={() => setHoveredEffect(null)}
                            >
                              <Badge className="bg-[#FF5722] text-white text-xs cursor-help">
                                {effect}
                              </Badge>
                              {hoveredEffect === effect && effectDescriptions[effect] && (
                                <div className="absolute z-10 bottom-full left-0 mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                                  <div className="font-bold mb-1">{effect}</div>
                                  {effectDescriptions[effect]}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {spellSlots.level1 > 0 && (
        <div>
          <h3 className="text-xl font-bold text-[#5B4B9E] mb-4">1st Level Spells</h3>
          <div className="grid grid-cols-2 gap-4">
            {availableSpells.level1.map((spell) => {
              const details = spellDetails[spell] || {
                level: "1st-level",
                school: "Various",
                castingTime: "1 action",
                range: "Varies",
                components: "V, S",
                duration: "Instantaneous",
                description: "A 1st level spell.",
                effects: []
              };
              const isSelected = selectedLevel1.includes(spell);
              const isDisabled = !isSelected && selectedLevel1.length >= spellSlots.level1;

              return (
                <div
                  key={spell}
                  onClick={() => !isDisabled && handleLevel1Toggle(spell, !isSelected)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#2A3441] border-[#37F2D1] border-4'
                      : 'bg-[#2A3441] border-[#1E2430]'
                  } ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-[#37F2D1]/50'}`}
                >
                  <div className="flex items-start gap-3 mb-2">
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={(checked) => handleLevel1Toggle(spell, checked)}
                      disabled={isDisabled}
                      className="mt-1 border-white pointer-events-none"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-[#FFC6AA]">{spell}</h4>
                      <div className="text-xs text-gray-400 mb-2">
                        {details.school} • {details.castingTime} • {details.range}
                      </div>
                      <p className="text-xs text-white leading-relaxed">{details.description}</p>
                      {details.effects && details.effects.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {details.effects.map((effect, idx) => (
                            <div
                              key={idx}
                              className="relative"
                              onMouseEnter={() => setHoveredEffect(effect)}
                              onMouseLeave={() => setHoveredEffect(null)}
                            >
                              <Badge className="bg-[#FF5722] text-white text-xs cursor-help">
                                {effect}
                              </Badge>
                              {hoveredEffect === effect && effectDescriptions[effect] && (
                                <div className="absolute z-10 bottom-full left-0 mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-lg border-2 border-[#FF5722]">
                                  <div className="font-bold mb-1">{effect}</div>
                                  {effectDescriptions[effect]}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
