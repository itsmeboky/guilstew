export const spellsByClass = {
  Bard: {
    cantrips: ["Blade Ward", "Dancing Lights", "Friends", "Light", "Mage Hand", "Mending", "Message", "Minor Illusion", "Prestidigitation", "True Strike", "Vicious Mockery"],
    level1: ["Animal Friendship", "Bane", "Charm Person", "Comprehend Languages", "Cure Wounds", "Detect Magic", "Disguise Self", "Dissonant Whispers", "Faerie Fire", "Feather Fall", "Healing Word", "Heroism", "Identify", "Illusory Script", "Longstrider", "Silent Image", "Sleep", "Speak with Animals", "Tasha's Hideous Laughter", "Thunderwave", "Unseen Servant"]
  },
  Cleric: {
    cantrips: ["Guidance", "Light", "Mending", "Resistance", "Sacred Flame", "Spare the Dying", "Thaumaturgy"],
    level1: ["Bane", "Bless", "Command", "Create or Destroy Water", "Cure Wounds", "Detect Evil and Good", "Detect Magic", "Detect Poison and Disease", "Guiding Bolt", "Healing Word", "Inflict Wounds", "Protection from Evil and Good", "Purify Food and Drink", "Sanctuary", "Shield of Faith"]
  },
  Druid: {
    cantrips: ["Druidcraft", "Guidance", "Mending", "Poison Spray", "Produce Flame", "Resistance", "Shillelagh", "Thorn Whip"],
    level1: ["Animal Friendship", "Charm Person", "Create or Destroy Water", "Cure Wounds", "Detect Magic", "Detect Poison and Disease", "Entangle", "Faerie Fire", "Fog Cloud", "Goodberry", "Healing Word", "Jump", "Longstrider", "Purify Food and Drink", "Speak with Animals", "Thunderwave"]
  },
  Sorcerer: {
    cantrips: ["Acid Splash", "Blade Ward", "Chill Touch", "Dancing Lights", "Fire Bolt", "Friends", "Light", "Mage Hand", "Mending", "Message", "Minor Illusion", "Poison Spray", "Prestidigitation", "Ray of Frost", "Shocking Grasp", "True Strike"],
    level1: ["Burning Hands", "Charm Person", "Chromatic Orb", "Color Spray", "Comprehend Languages", "Detect Magic", "Disguise Self", "Expeditious Retreat", "False Life", "Feather Fall", "Fog Cloud", "Jump", "Mage Armor", "Magic Missile", "Ray of Sickness", "Shield", "Silent Image", "Sleep", "Thunderwave", "Witch Bolt"]
  },
  Warlock: {
    cantrips: ["Blade Ward", "Chill Touch", "Eldritch Blast", "Friends", "Mage Hand", "Minor Illusion", "Poison Spray", "Prestidigitation", "True Strike"],
    level1: ["Armor of Agathys", "Arms of Hadar", "Charm Person", "Comprehend Languages", "Expeditious Retreat", "Hellish Rebuke", "Hex", "Illusory Script", "Protection from Evil and Good", "Unseen Servant", "Witch Bolt"]
  },
  Wizard: {
    cantrips: ["Acid Splash", "Blade Ward", "Chill Touch", "Dancing Lights", "Fire Bolt", "Friends", "Light", "Mage Hand", "Mending", "Message", "Minor Illusion", "Poison Spray", "Prestidigitation", "Ray of Frost", "Shocking Grasp", "True Strike"],
    level1: ["Alarm", "Burning Hands", "Charm Person", "Chromatic Orb", "Color Spray", "Comprehend Languages", "Detect Magic", "Disguise Self", "Expeditious Retreat", "False Life", "Feather Fall", "Find Familiar", "Fog Cloud", "Grease", "Identify", "Illusory Script", "Jump", "Longstrider", "Mage Armor", "Magic Missile", "Protection from Evil and Good", "Ray of Sickness", "Shield", "Silent Image", "Sleep", "Tasha's Hideous Laughter", "Tenser's Floating Disk", "Thunderwave", "Unseen Servant", "Witch Bolt"]
  },
  Paladin: {
    cantrips: [],
    level1: ["Bless", "Command", "Compelled Duel", "Cure Wounds", "Detect Evil and Good", "Detect Magic", "Detect Poison and Disease", "Divine Favor", "Heroism", "Protection from Evil and Good", "Purify Food and Drink", "Searing Smite", "Shield of Faith", "Thunderous Smite", "Wrathful Smite"]
  },
  Ranger: {
    cantrips: [],
    level1: ["Alarm", "Animal Friendship", "Cure Wounds", "Detect Magic", "Detect Poison and Disease", "Ensnaring Strike", "Fog Cloud", "Goodberry", "Hail of Thorns", "Hunter's Mark", "Jump", "Longstrider", "Speak with Animals"]
  }
};

export const recommendedSpells = {
  Paladin: {
    cantrips: [],
    level1: ["Bless", "Cure Wounds", "Shield of Faith"],
    reasoning: "Bless is one of the best buff spells in the game. Cure Wounds provides solid healing. Shield of Faith gives you or an ally +2 AC which is huge for survivability."
  },
  Ranger: {
    cantrips: [],
    level1: ["Hunter's Mark", "Goodberry", "Cure Wounds"],
    reasoning: "Hunter's Mark is your signature spell for boosting damage. Goodberry provides efficient healing outside combat. Cure Wounds for emergency healing during fights."
  },
  Bard: {
    cantrips: ["Vicious Mockery", "Minor Illusion"],
    level1: ["Healing Word", "Faerie Fire", "Sleep"],
    reasoning: "Vicious Mockery is Bard's signature damage cantrip that also debuffs enemies. Healing Word is crucial for picking up downed allies as a bonus action. Faerie Fire helps your party hit enemies. Sleep can end encounters at low levels."
  },
  Cleric: {
    cantrips: ["Sacred Flame", "Guidance"],
    level1: ["Bless", "Cure Wounds", "Healing Word", "Guiding Bolt"],
    reasoning: "Sacred Flame is a reliable damage cantrip. Guidance helps with skill checks. Bless is one of the best support spells. Healing Word saves allies as a bonus action. Guiding Bolt deals great damage and helps allies."
  },
  Druid: {
    cantrips: ["Guidance", "Produce Flame"],
    level1: ["Healing Word", "Entangle", "Goodberry", "Faerie Fire"],
    reasoning: "Guidance helps with skill checks. Produce Flame is versatile for damage and light. Entangle controls the battlefield. Goodberry provides out-of-combat healing. Faerie Fire grants advantage to allies."
  },
  Sorcerer: {
    cantrips: ["Fire Bolt", "Mage Hand"],
    level1: ["Shield", "Magic Missile", "Mage Armor", "Chromatic Orb"],
    reasoning: "Fire Bolt is reliable damage. Shield keeps you alive. Magic Missile never misses. Mage Armor increases your AC. Chromatic Orb offers versatile elemental damage."
  },
  Warlock: {
    cantrips: ["Eldritch Blast"],
    level1: ["Hex", "Armor of Agathys"],
    reasoning: "Eldritch Blast is your bread and butter - it scales incredibly well. Hex boosts your damage significantly. Armor of Agathys provides both defense and offense."
  },
  Wizard: {
    cantrips: ["Fire Bolt", "Mage Hand"],
    level1: ["Shield", "Mage Armor", "Magic Missile", "Find Familiar", "Detect Magic"],
    reasoning: "Fire Bolt for damage. Shield keeps you alive. Mage Armor for defense. Magic Missile for guaranteed damage. Find Familiar is incredibly versatile. Detect Magic for exploration."
  }
};

export const spellDetails = {
  // Cantrips
  "Acid Splash": { level: "Cantrip", school: "Conjuration", castingTime: "1 action", range: "60 feet", components: "V, S", duration: "Instantaneous", description: "1d6 acid damage against up to two adjacent targets, Dex saves. Damage increases with higher caster level.", effects: [] },
  "Blade Ward": { level: "Cantrip", school: "Abjuration", castingTime: "1 action", range: "Self", components: "V, S", duration: "1 round", description: "Resistance to bludgeoning, piercing, slashing until your next turn.", effects: [] },
  "Chill Touch": { level: "Cantrip", school: "Necromancy", castingTime: "1 action", range: "120 feet", components: "V, S", duration: "1 round", description: "Target takes 1d8 necrotic damage and can't heal until your next turn. Damage increases at higher caster levels.", effects: [] },
  "Dancing Lights": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "120 feet", components: "V, S, M", duration: "Concentration, up to 1 minute", description: "Creates four torch-sized lights, which illuminate 10' and can be moved 60' as a bonus action.", effects: [] },
  "Druidcraft": { level: "Cantrip", school: "Transmutation", castingTime: "1 action", range: "30 feet", components: "V, S", duration: "Instantaneous", description: "Cause one of several minor nature-related effects: weather report for the next 24h, plant blooming, 5' cube of sensory effect, and lighting or snuffing out a small fire.", effects: [] },
  "Eldritch Blast": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "120 feet", components: "V, S", duration: "Instantaneous", description: "Deals 1d10 force damage to target. More attacks at higher caster levels.", effects: [] },
  "Fire Bolt": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "120 feet", components: "V, S", duration: "Instantaneous", description: "Target takes 1d10 fire damage. Damage increases at higher caster levels.", effects: [] },
  "Friends": { level: "Cantrip", school: "Enchantment", castingTime: "1 action", range: "Self", components: "S, M", duration: "Concentration, up to 1 minute", description: "Grants advantage on Cha checks against target, but at the end, the creature knows you used magic on it and becomes hostile.", effects: [] },
  "Guidance": { level: "Cantrip", school: "Divination", castingTime: "1 action", range: "Touch", components: "V, S", duration: "Concentration, up to 1 minute", description: "Target can roll 1d4 and add it to a single ability check, at which point the spell ends.", effects: [] },
  "Light": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "Touch", components: "V, M", duration: "1 hour", description: "Object sheds 20' of bright light and an additional 20' of dim light.", effects: [] },
  "Mage Hand": { level: "Cantrip", school: "Conjuration", castingTime: "1 action", range: "30 feet", components: "V, S", duration: "1 minute", description: "Creates spectral hand that can lift 10lbs, but not attack or activate magic items.", effects: [] },
  "Mending": { level: "Cantrip", school: "Transmutation", castingTime: "1 minute", range: "Touch", components: "V, S, M", duration: "Instantaneous", description: "Repairs a single break or tear in the touched object.", effects: [] },
  "Message": { level: "Cantrip", school: "Transmutation", castingTime: "1 action", range: "120 feet", components: "V, S, M", duration: "1 round", description: "Sends a whispered message to a target which only they can hear. Can send through sufficiently thin solid objects if you know the target.", effects: [] },
  "Minor Illusion": { level: "Cantrip", school: "Illusion", castingTime: "1 action", range: "30 feet", components: "S, M", duration: "1 minute", description: "Creates an auditory or visual hallucination; if visual, must fit in a 5' cube.", effects: [] },
  "Poison Spray": { level: "Cantrip", school: "Conjuration", castingTime: "1 action", range: "10 feet", components: "V, S", duration: "Instantaneous", description: "Target takes 1d12 poison damage, Con save prevents. Damage increases at higher caster levels.", effects: [] },
  "Prestidigitation": { level: "Cantrip", school: "Transmutation", castingTime: "1 action", range: "10 feet", components: "V, S", duration: "Special", description: "Creates one of a variety of minor, practical effects, such as sparks of light, cleaning or soiling 1 cubic foot, chilling, warming, or flavoring nonliving matter for an hour, or creating an illusion in your hand until the end of your next turn.", effects: [] },
  "Produce Flame": { level: "Cantrip", school: "Conjuration", castingTime: "1 action", range: "Self", components: "V, S", duration: "10 minutes", description: "Ranged spell attack within 30' deals 1d8 fire damage. Damage increases at higher levels.", effects: [] },
  "Ray of Frost": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "60 feet", components: "V, S", duration: "Instantaneous", description: "Target takes 1d8 cold damage and loses 10' of move speed for a turn. Damage increases at higher caster levels.", effects: [] },
  "Resistance": { level: "Cantrip", school: "Abjuration", castingTime: "1 action", range: "Touch", components: "V, S, M", duration: "Concentration, up to 1 minute", description: "Lets the target creature add +1d4 to a save, once, then the spell ends.", effects: [] },
  "Sacred Flame": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "60 feet", components: "V, S", duration: "Instantaneous", description: "1d8 radiant damage, Dex save stops. Damage increases with caster level.", effects: [] },
  "Shillelagh": { level: "Cantrip", school: "Transmutation", castingTime: "1 bonus action", range: "Touch", components: "V, S, M", duration: "1 minute", description: "Held club or quarterstaff uses spellcasting ability instead of Strength for attack and damage rolls, weapon's damage die becomes d8, and weapon becomes magical.", effects: [] },
  "Shocking Grasp": { level: "Cantrip", school: "Evocation", castingTime: "1 action", range: "Touch", components: "V, S", duration: "Instantaneous", description: "Target takes 1d8 lightning damage, and can't take reactions. Damage increases at higher caster levels.", effects: [] },
  "Spare the Dying": { level: "Cantrip", school: "Necromancy", castingTime: "1 action", range: "Touch", components: "V, S", duration: "Instantaneous", description: "Target creature at 0 hp is stabilized.", effects: [] },
  "Thaumaturgy": { level: "Cantrip", school: "Transmutation", castingTime: "1 action", range: "30 feet", components: "V", duration: "1 minute", description: "Manifest a minor effect that is suggestive of supernatural power, such as making your voice loud, causing flames to flicker or change color, or altering the appearance of your eyes. Up to three such effects can be active at a time.", effects: [] },
  "Thorn Whip": { level: "Cantrip", school: "Transmutation", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "Instantaneous", description: "Melee spell attack deals 1d6 piercing damage, and if it is Large or smaller, is pulled 10' towards you. Higher caster levels increase damage.", effects: [] },
  "True Strike": { level: "Cantrip", school: "Divination", castingTime: "1 action", range: "30 feet", components: "S", duration: "Concentration, up to 1 round", description: "Grants advantage on an attack roll against chosen creature next round.", effects: [] },
  "Vicious Mockery": { level: "Cantrip", school: "Enchantment", castingTime: "1 action", range: "60 feet", components: "V", duration: "Instantaneous", description: "Target takes 1d4 psychic and has disadvantage on next attack roll, Wis save stops damage and effect. Higher caster levels increase damage.", effects: [] },

  // 1st Level Spells
  "Alarm": { level: "1st-level", school: "Abjuration", castingTime: "1 minute", range: "30 feet", components: "V, S, M", duration: "8 hours", description: "Sets an alarm which pings you if you're within a mile when something passes through the marked area.", effects: [] },
  "Animal Friendship": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "24 hours", description: "Charms a beast with less than 3 Intelligence for the day. Upcast to charm 1 more beast per level.", effects: ["Charmed"] },
  "Armor of Agathys": { level: "1st-level", school: "Abjuration", castingTime: "1 action", range: "Self", components: "V, S, M", duration: "1 hour", description: "+5 temporary HP, and 5 cold damage to melee attackers while you have the temporary HP. Upcasting increases both temporary HP and cold damage.", effects: [] },
  "Arms of Hadar": { level: "1st-level", school: "Conjuration", castingTime: "1 action", range: "Self", components: "V, S", duration: "Instantaneous", description: "Creatures within 10' of caster must save or take 2d6 necrotic damage. Upcasting increases damage.", effects: [] },
  "Bane": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "Concentration, up to 1 minute", description: "Up to three creatures must make a Cha save or suffer a 1d4 penalty each time they attack or save. Upcasting increases the number of targets by 1 per level.", effects: [] },
  "Bless": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "Concentration, up to 1 minute", description: "Target adds 1d4 to all attack rolls and saves. Upcasting increases the number of targets by 1 per level.", effects: [] },
  "Burning Hands": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "Self", components: "V, S", duration: "Instantaneous", description: "15' cone of 3d6 fire damage, Dex save halves. Upcasting increases damage by 1d6 per level.", effects: [] },
  "Charm Person": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "30 feet", components: "V, S", duration: "1 hour", description: "Wis save or target is charmed, and thinks of you as a friendly acquaintance, realizing magic was used on it when the duration ends. Upcasting increases the number of targets by 1 per level.", effects: ["Charmed"] },
  "Chromatic Orb": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "90 feet", components: "V, S, M", duration: "Instantaneous", description: "Deals 3d8 damage of acid, cold, fire, lightning, poison or thunder type, your choice. Upcasting increases damage by 1d8 per level.", effects: [] },
  "Color Spray": { level: "1st-level", school: "Illusion", castingTime: "1 action", range: "Self", components: "V, S, M", duration: "1 round", description: "Blinds 6d10 hit points worth of creatures in 15' cone. Upcasting increases total hit points of creatures by 2d10 per level.", effects: ["Blinded"] },
  "Command": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "60 feet", components: "V", duration: "1 round", description: "Issue a one word command that is not harmful to the target. Wisdom save counters. Upcasting adds one target per level.", effects: [] },
  "Compelled Duel": { level: "1st-level", school: "Enchantment", castingTime: "1 bonus action", range: "30 feet", components: "V", duration: "Concentration, up to 1 minute", description: "Target must make Wis save or be compelled to fight you and stay near, so long as you stay in a one-on-one with it.", effects: [] },
  "Comprehend Languages": { level: "1st-level", school: "Divination", castingTime: "1 action", range: "Self", components: "V, S, M", duration: "1 hour", description: "Allows you to understand any spoken or written language for an hour.", effects: [] },
  "Create or Destroy Water": { level: "1st-level", school: "Transmutation", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "Instantaneous", description: "Creates or destroys 10gal of water, can be used to create 30' rain or disperse 30' fog. Upcast for +10gal/+5' area per level.", effects: [] },
  "Cure Wounds": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "Touch", components: "V, S", duration: "Instantaneous", description: "Heals 1d8 + (spellcasting ability modifier) damage. Upcasting heals an additional 1d8 per level.", effects: [] },
  "Detect Evil and Good": { level: "1st-level", school: "Divination", castingTime: "1 action", range: "Self", components: "V, S", duration: "Concentration, up to 10 minutes", description: "Recognizes aberration, celestial, fey, fiend, or undead, as well as magical consecration/desecration, within 30'.", effects: [] },
  "Detect Magic": { level: "1st-level", school: "Divination", castingTime: "1 action", range: "Self", components: "V, S", duration: "Concentration, up to 10 minutes", description: "Senses magical objects or creatures within 30', and school of magic.", effects: [] },
  "Detect Poison and Disease": { level: "1st-level", school: "Divination", castingTime: "1 action", range: "Self", components: "V, S, M", duration: "Concentration, up to 10 minutes", description: "Senses poison, poisonous creatures, and disease within 30', and identifies type of poison, poisonous creature, or disease.", effects: [] },
  "Disguise Self": { level: "1st-level", school: "Illusion", castingTime: "1 action", range: "Self", components: "V, S", duration: "1 hour", description: "Makes you and your armor look like another person; purely illusory.", effects: [] },
  "Dissonant Whispers": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "60 feet", components: "V", duration: "Instantaneous", description: "3d6 psychic damage, and target must use reaction to flee you. Wis save for half damage, no effect.", effects: [] },
  "Divine Favor": { level: "1st-level", school: "Evocation", castingTime: "1 bonus action", range: "Self", components: "V, S", duration: "Concentration, up to 1 minute", description: "Weapon deals +1d4 radiant damage.", effects: [] },
  "Ensnaring Strike": { level: "1st-level", school: "Conjuration", castingTime: "1 bonus action", range: "Self", components: "V", duration: "Concentration, up to 1 minute", description: "When you next hit an opponent with your weapon, target is restrained by vines, and takes 1d6 piercing damage at the start of each turn. Str save prevents, and can spend an action to try again. Upcasting adds +1d6 damage per level.", effects: ["Restrained"] },
  "Entangle": { level: "1st-level", school: "Conjuration", castingTime: "1 action", range: "90 feet", components: "V, S", duration: "Concentration, up to 1 minute", description: "20' square of difficult terrain. Creatures in area must make Str save or be restrained, spending an action to try again.", effects: ["Restrained"] },
  "Expeditious Retreat": { level: "1st-level", school: "Transmutation", castingTime: "1 bonus action", range: "Self", components: "V, S", duration: "Concentration, up to 10 minutes", description: "Can take the Dash action as a bonus action while spell is active.", effects: [] },
  "Faerie Fire": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "60 feet", components: "V", duration: "Concentration, up to 1 minute", description: "Objects and people in a 20' cube are lit up, counteracting invisibility for the duration. Dex save prevents.", effects: [] },
  "False Life": { level: "1st-level", school: "Necromancy", castingTime: "1 action", range: "Self", components: "V, S, M", duration: "1 hour", description: "Gives you 1d4 + 4 temporary hit points for duration. Upcasting adds +5 hit points per level.", effects: [] },
  "Feather Fall": { level: "1st-level", school: "Transmutation", castingTime: "1 reaction", range: "60 feet", components: "V, M", duration: "1 minute", description: "Up to five falling creatures have their descent velocity capped at 60'/round. If they hit the ground while the spell is ongoing, they take no fall damage.", effects: [] },
  "Find Familiar": { level: "1st-level", school: "Conjuration", castingTime: "1 hour", range: "10 feet", components: "V, S, M", duration: "Instantaneous", description: "Summons a creature to act as your familiar. Can sense via familiar, telepathically communicate, resummon if dead, or use as a proxy for touch-range spells.", effects: [] },
  "Fog Cloud": { level: "1st-level", school: "Conjuration", castingTime: "1 action", range: "120 feet", components: "V, S", duration: "Concentration, up to 1 hour", description: "20' fog heavily obscures area. Upcasting adds +20' radius per level.", effects: [] },
  "Goodberry": { level: "1st-level", school: "Transmutation", castingTime: "1 action", range: "Touch", components: "V, S, M", duration: "Instantaneous", description: "Creates ten magic berries that each heal 1 hit point and provide a day's nourishment.", effects: [] },
  "Grease": { level: "1st-level", school: "Conjuration", castingTime: "1 action", range: "60 feet", components: "V, S, M", duration: "1 minute", description: "10' square of area is covered in grease, making those in the area, ending their turn on the area, or entering the area, fall prone; Dex save prevents.", effects: ["Prone"] },
  "Guiding Bolt": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "120 feet", components: "V, S", duration: "1 round", description: "Ranged attack dealing 4d6 radiant damage and giving advantage on the next attack roll. Upcasting is +1d6 per level.", effects: [] },
  "Hail of Thorns": { level: "1st-level", school: "Conjuration", castingTime: "1 bonus action", range: "Self", components: "V", duration: "Concentration, up to 1 minute", description: "Around next creature struck with ranged weapon attack, deal 1d10 pierce to target and all within 5', Dex save halves. Upcasting +1d10 per level (cap 6d10).", effects: [] },
  "Healing Word": { level: "1st-level", school: "Evocation", castingTime: "1 bonus action", range: "60 feet", components: "V", duration: "Instantaneous", description: "Creature regains 1d4 + (spellcasting ability mod) HP. Upcasting adds +1d4 healing per level.", effects: [] },
  "Hellish Rebuke": { level: "1st-level", school: "Evocation", castingTime: "1 reaction", range: "60 feet", components: "V, S", duration: "Instantaneous", description: "Person that damaged you takes 2d10 fire damage, Dex save halves. Upcasting adds +1d10 damage per level.", effects: [] },
  "Heroism": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "Touch", components: "V, S", duration: "Concentration, up to 1 minute", description: "Creature gains immunity to being frightened and gains temporary hit points equal to your spellcasting ability modifier at the start of its turn. Upcasting adds +1 target per level.", effects: [] },
  "Hex": { level: "1st-level", school: "Enchantment", castingTime: "1 bonus action", range: "90 feet", components: "V, S, M", duration: "Concentration, up to 1 hour", description: "You deal an extra 1d6 necrotic damage to the target whenever you hit it with an attack, and the target suffers disadvantage to checks with one ability score (your choice). Upcasting increases duration.", effects: [] },
  "Hunter's Mark": { level: "1st-level", school: "Divination", castingTime: "1 bonus action", range: "90 feet", components: "V", duration: "Concentration, up to 1 hour", description: "Marks target, granting +1d6 damage and advantage to Perception and Survival checks to find it. Upcasting increases duration.", effects: [] },
  "Identify": { level: "1st-level", school: "Divination", castingTime: "1 minute", range: "Touch", components: "V, S, M", duration: "Instantaneous", description: "Identifies what a magical item does, what magic created an object, and what spells are currently affecting a touched creature.", effects: [] },
  "Illusory Script": { level: "1st-level", school: "Illusion", castingTime: "1 minute", range: "Touch", components: "S, M", duration: "10 days", description: "Only designated creatures and those with truesight can read your hidden message, with a false or gibberish text appearing for all others.", effects: [] },
  "Inflict Wounds": { level: "1st-level", school: "Necromancy", castingTime: "1 action", range: "Touch", components: "V, S", duration: "Instantaneous", description: "Deals 3d10 necrotic damage. Upcasting adds +1d10 per level.", effects: [] },
  "Jump": { level: "1st-level", school: "Transmutation", castingTime: "1 action", range: "Touch", components: "V, S, M", duration: "1 minute", description: "Triples target's jump distance.", effects: [] },
  "Longstrider": { level: "1st-level", school: "Transmutation", castingTime: "1 action", range: "Touch", components: "V, S, M", duration: "1 hour", description: "Target's speed increases by +10'. Upcasting adds +1 creature per level.", effects: [] },
  "Mage Armor": { level: "1st-level", school: "Abjuration", castingTime: "1 action", range: "Touch", components: "V, S, M", duration: "8 hours", description: "Target's AC becomes 13 + Dex. Only works on those not wearing armor.", effects: [] },
  "Magic Missile": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "120 feet", components: "V, S", duration: "Instantaneous", description: "Three darts, each of which deal 1d4 + 1 damage. Upcasting adds 1 dart per level.", effects: [] },
  "Protection from Evil and Good": { level: "1st-level", school: "Abjuration", castingTime: "1 action", range: "Touch", components: "V, S, M", duration: "Concentration, up to 10 minutes", description: "Target creature is protected against aberrations, celestials, elementals, fey, fiends, and undead. Against such creatures, the target gains various benefits.", effects: [] },
  "Purify Food and Drink": { level: "1st-level", school: "Transmutation", castingTime: "1 action", range: "10 feet", components: "V, S", duration: "Instantaneous", description: "All nonmagical food and drink within 5' is purified and free of poison and disease.", effects: [] },
  "Ray of Sickness": { level: "1st-level", school: "Necromancy", castingTime: "1 action", range: "60 feet", components: "V, S", duration: "Instantaneous", description: "Target takes 2d8 poison damage and is poisoned for a turn. Con save clears poison, but not damage. Upcasting increases damage by 1d8 per level.", effects: ["Poisoned"] },
  "Sanctuary": { level: "1st-level", school: "Abjuration", castingTime: "1 bonus action", range: "30 feet", components: "V, S, M", duration: "1 minute", description: "Any creature wishing to attack the chosen creature must make a Wis save; on a fail, they must target someone else. Spell ends if warded creature attacks or casts an offensive spell.", effects: [] },
  "Searing Smite": { level: "1st-level", school: "Evocation", castingTime: "1 bonus action", range: "Self", components: "V", duration: "Concentration, up to 1 minute", description: "Adds 1d6 fire damage to next melee weapon attack. Target struck makes Con save at end of each turn, failure inflicts additional 1d6 fire damage, save ends. Upcasting increases initial damage +1d6 per level.", effects: [] },
  "Shield": { level: "1st-level", school: "Abjuration", castingTime: "1 reaction", range: "Self", components: "V, S", duration: "1 round", description: "In response to an attack or magic missile, +5 AC and immunity to magic missile until your next turn.", effects: [] },
  "Shield of Faith": { level: "1st-level", school: "Abjuration", castingTime: "1 bonus action", range: "60 feet", components: "V, S, M", duration: "Concentration, up to 10 minutes", description: "Grants +2 AC to target for duration.", effects: [] },
  "Silent Image": { level: "1st-level", school: "Illusion", castingTime: "1 action", range: "60 feet", components: "V, S, M", duration: "Concentration, up to 10 minutes", description: "Creates a visual illusion that you can move and make look as if it's moving naturally.", effects: [] },
  "Sleep": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "90 feet", components: "V, S, M", duration: "1 minute", description: "5d8 hit points of creatures are put to sleep. Upcasting adds +2d8 HP of targets per level.", effects: ["Unconscious"] },
  "Speak with Animals": { level: "1st-level", school: "Divination", castingTime: "1 action", range: "Self", components: "V, S", duration: "10 minutes", description: "You can speak and verbally communicate with beasts for the duration.", effects: [] },
  "Tasha's Hideous Laughter": { level: "1st-level", school: "Enchantment", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "Concentration, up to 1 minute", description: "Target falls prone and is incapacitated, unable to stand. Wis save prevents. Each turn and when damaged, target can make fresh Wis save.", effects: ["Prone", "Incapacitated"] },
  "Tenser's Floating Disk": { level: "1st-level", school: "Conjuration", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "1 hour", description: "3' diameter floating disk carries up to 500lbs and follows you at a distance of 20'.", effects: [] },
  "Thunderous Smite": { level: "1st-level", school: "Evocation", castingTime: "1 bonus action", range: "Self", components: "V", duration: "Concentration, up to 1 minute", description: "Next attack deals 2d6 thunder damage to the target and pushes it 10' away, knocking it prone. Str save prevents effect but not damage.", effects: ["Prone"] },
  "Thunderwave": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "Self", components: "V, S", duration: "Instantaneous", description: "Those within 15' take 2d8 thunder damage and are pushed 10' away. Con save halves damage and prevents push. Upcasting increases damage by +1d8 per level.", effects: [] },
  "Unseen Servant": { level: "1st-level", school: "Conjuration", castingTime: "1 action", range: "60 feet", components: "V, S, M", duration: "1 hour", description: "Creates an invisible servant incapable of attacking that performs simple tasks at your command. You can give new commands as a bonus action.", effects: [] },
  "Witch Bolt": { level: "1st-level", school: "Evocation", castingTime: "1 action", range: "30 feet", components: "V, S, M", duration: "Concentration, up to 1 minute", description: "Deals 1d12 lightning damage, and you can spend your action to deal another 1d12 lightning damage each round. Upcasting increases initial damage by +1d12 per level.", effects: [] },
  "Wrathful Smite": { level: "1st-level", school: "Evocation", castingTime: "1 bonus action", range: "Self", components: "V", duration: "Concentration, up to 1 minute", description: "Next melee weapon attack deals 1d6 psychic damage and is frightened until the spell ends, Wis save prevents effect. As an action, creature can take Wis save to end the effect.", effects: ["Frightened"] }
};

export const effectDescriptions = {
  "Unconscious": "An unconscious creature is incapacitated, can't move or speak, and is unaware of its surroundings. The creature drops whatever it's holding and falls prone. The creature automatically fails Strength and Dexterity saving throws. Attack rolls against the creature have advantage. Any attack that hits the creature is a critical hit if the attacker is within 5 feet of the creature.",
  "Charmed": "A charmed creature can't attack the charmer or target the charmer with harmful abilities or magical effects. The charmer has advantage on any ability check to interact socially with the creature.",
  "Stunned": "A stunned creature is incapacitated, can't move, and can speak only falteringly. The creature automatically fails Strength and Dexterity saving throws. Attack rolls against the creature have advantage.",
  "Prone": "A prone creature's only movement option is to crawl, unless it stands up. The creature has disadvantage on attack rolls. An attack roll against the creature has advantage if the attacker is within 5 feet, otherwise disadvantage.",
  "Blinded": "A blinded creature can't see and automatically fails any ability check that requires sight. Attack rolls against the creature have advantage, and the creature's attack rolls have disadvantage.",
  "Frightened": "A frightened creature has disadvantage on ability checks and attack rolls while the source of its fear is within line of sight. The creature can't willingly move closer to the source of its fear.",
  "Restrained": "A restrained creature's speed becomes 0, and it can't benefit from any bonus to its speed. Attack rolls against the creature have advantage, and the creature's attack rolls have disadvantage. The creature has disadvantage on Dexterity saving throws.",
  "Incapacitated": "An incapacitated creature can't take actions or reactions.",
  "Poisoned": "A poisoned creature has disadvantage on attack rolls and ability checks."
};

export function getSpellSlots(className, level, multiclasses = []) {
  let totalSpellSlots = { cantrips: 0, level1: 0 };
  
  const primarySlots = getSingleClassSpellSlots(className, level);
  
  multiclasses.forEach(mc => {
    if (mc.class && mc.level) {
      const mcSlots = getSingleClassSpellSlots(mc.class, mc.level);
      totalSpellSlots.cantrips = Math.max(totalSpellSlots.cantrips, mcSlots.cantrips);
      totalSpellSlots.level1 += mcSlots.level1;
    }
  });
  
  totalSpellSlots.cantrips = Math.max(totalSpellSlots.cantrips, primarySlots.cantrips);
  totalSpellSlots.level1 += primarySlots.level1;
  
  return totalSpellSlots;
}

function getSingleClassSpellSlots(className, level) {
  if (["Fighter", "Barbarian", "Rogue", "Monk"].includes(className)) {
    return { cantrips: 0, level1: 0 };
  }
  
  if (["Paladin", "Ranger"].includes(className)) {
    if (level < 2) return { cantrips: 0, level1: 0 };
    if (level === 2) return { cantrips: 0, level1: 2 };
    if (level === 3 || level === 4) return { cantrips: 0, level1: 3 };
    return { cantrips: 0, level1: 4 };
  }
  
  const fullCasters = ["Bard", "Cleric", "Druid", "Sorcerer", "Wizard", "Warlock"];
  if (fullCasters.includes(className)) {
    const cantripsKnown = level >= 10 ? 4 : level >= 4 ? 3 : 2;
    const level1Slots = level === 1 ? 2 : level === 2 ? 3 : 4;
    return { cantrips: cantripsKnown, level1: level1Slots };
  }
  
  return { cantrips: 0, level1: 0 };
}

export function getAllAvailableSpells(primaryClass, multiclasses = []) {
  let allSpells = { cantrips: [], level1: [] };
  
  const primarySpells = spellsByClass[primaryClass] || { cantrips: [], level1: [] };
  allSpells.cantrips = [...primarySpells.cantrips];
  allSpells.level1 = [...primarySpells.level1];
  
  multiclasses.forEach(mc => {
    if (mc.class && mc.level >= 1) {
      const mcSpells = spellsByClass[mc.class] || { cantrips: [], level1: [] };
      allSpells.cantrips = [...new Set([...allSpells.cantrips, ...mcSpells.cantrips])];
      allSpells.level1 = [...new Set([...allSpells.level1, ...mcSpells.level1])];
    }
  });
  
  return allSpells;
}