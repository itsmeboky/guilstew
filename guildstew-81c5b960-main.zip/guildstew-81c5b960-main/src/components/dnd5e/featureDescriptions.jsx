export const classFeatureDescriptions = {
  // Barbarian
  "Rage": "In battle, you fight with primal ferocity. While raging, you gain advantage on Strength checks and saves, bonus damage on melee attacks, and resistance to physical damage.",
  "Unarmored Defense": "While not wearing armor, your AC equals 10 + Dex modifier + Con modifier.",
  "Reckless Attack": "Gain advantage on melee weapon attacks using Strength, but attack rolls against you have advantage until your next turn.",
  "Danger Sense": "Advantage on Dexterity saving throws against effects you can see.",
  "Primal Path": "Choose a path that shapes your rage: Berserker, Totem Warrior, etc.",
  
  // Bard
  "Spellcasting": "You can cast spells using Charisma as your spellcasting ability.",
  "Bardic Inspiration": "Use a bonus action to grant an ally a d6 (scales with level) they can add to ability checks, attack rolls, or saving throws.",
  "Jack of All Trades": "Add half your proficiency bonus to ability checks that don't already include it.",
  "Song of Rest": "During a short rest, allies who use Hit Dice to heal regain extra hit points.",
  "Bard College": "Choose a college that defines your bardic style: Lore, Valor, etc.",
  "Expertise": "Double your proficiency bonus for two skills you're proficient in.",
  
  // Cleric
  "Divine Domain": "Choose a domain related to your deity, granting domain spells and special abilities.",
  "Channel Divinity": "Channel divine energy to fuel magical effects, specific to your domain.",
  "Destroy Undead": "When you Turn Undead, creatures of low CR are destroyed instead of just turned.",
  
  // Druid
  "Druidic": "You know the secret language of druids, which you can use to leave hidden messages.",
  "Wild Shape": "Magically assume the shape of a beast you've seen before.",
  "Druid Circle": "Choose a circle of druids: Land, Moon, etc.",
  
  // Fighter
  "Fighting Style": "Choose a combat specialty: Archery, Defense, Dueling, Great Weapon Fighting, Protection, or Two-Weapon Fighting.",
  "Second Wind": "Use a bonus action to regain 1d10 + fighter level hit points once per short rest.",
  "Action Surge": "Take an additional action on your turn once per short rest.",
  "Martial Archetype": "Choose an archetype: Champion, Battle Master, or Eldritch Knight.",
  "Extra Attack": "Attack twice instead of once when you take the Attack action.",
  
  // Monk
  "Martial Arts": "Use Dexterity for unarmed strikes, roll martial arts die for damage, and make an unarmed strike as a bonus action.",
  "Ki": "Spend ki points to fuel special abilities like Flurry of Blows, Patient Defense, and Step of the Wind.",
  "Unarmored Movement": "Your speed increases by 10 feet while not wearing armor or wielding a shield.",
  "Monastic Tradition": "Choose a tradition: Open Hand, Shadow, Four Elements, etc.",
  
  // Paladin
  "Divine Sense": "Detect celestials, fiends, and undead within 60 feet as an action.",
  "Lay on Hands": "Heal wounds with a pool of hit points equal to paladin level × 5.",
  "Divine Smite": "Expend a spell slot when you hit with a melee weapon to deal extra radiant damage.",
  "Sacred Oath": "Swear an oath that grants features and spells: Devotion, Ancients, or Vengeance.",
  
  // Ranger
  "Favored Enemy": "Advantage on tracking and recalling information about a chosen enemy type.",
  "Natural Explorer": "Benefits when traveling in a chosen terrain type.",
  "Ranger Archetype": "Choose an archetype: Hunter or Beast Master.",
  
  // Rogue
  "Sneak Attack": "Deal extra damage once per turn when you have advantage or an ally is within 5 feet of target.",
  "Thieves' Cant": "Secret language and code used by thieves to hide messages.",
  "Cunning Action": "Use Dash, Disengage, or Hide as a bonus action.",
  "Roguish Archetype": "Choose an archetype: Thief, Assassin, or Arcane Trickster.",
  
  // Sorcerer
  "Sorcerous Origin": "Choose the source of your magic: Draconic Bloodline or Wild Magic.",
  "Font of Magic": "Tap into your magic to create sorcery points, which can be used to gain spell slots or fuel Metamagic.",
  "Metamagic": "Twist spells to suit your needs using options like Careful, Distant, Empowered, Extended, Heightened, Quickened, Subtle, or Twinned Spell.",
  
  // Warlock
  "Otherworldly Patron": "Your pact with a powerful being grants you magic: Archfey, Fiend, or Great Old One.",
  "Pact Magic": "Regain all spell slots on a short rest, but have fewer slots than other casters.",
  "Eldritch Invocations": "Fragments of forbidden knowledge that grant magical abilities.",
  "Pact Boon": "Your patron's gift: Pact of the Chain, Blade, or Tome.",
  
  // Wizard
  "Arcane Recovery": "Once per day during a short rest, recover spell slots up to half your wizard level.",
  "Arcane Tradition": "Choose a school of magic: Abjuration, Evocation, etc."
};

export const languageDescriptions = {
  "Common": "The most universal language spoken by all civilized humanoids.",
  "Dwarvish": "The guttural language of the dwarves, known for its harsh consonants.",
  "Elvish": "The flowing, melodic language of the elves.",
  "Giant": "The booming language spoken by giants and ogres.",
  "Gnomish": "The language of gnomes, full of technical terms and precise vocabulary.",
  "Goblin": "The harsh language spoken by goblinoids.",
  "Halfling": "A language rich with loanwords from other tongues.",
  "Orc": "A harsh, grating language with hard consonants.",
  "Abyssal": "The language of demons from the Abyss.",
  "Celestial": "The language of celestial beings.",
  "Draconic": "The ancient language of dragons and dragonborn.",
  "Deep Speech": "The alien language of aberrations.",
  "Infernal": "The language of devils from the Nine Hells.",
  "Primordial": "The language of elementals (includes Aquan, Auran, Ignan, and Terran dialects).",
  "Sylvan": "The language of the Feywild spoken by fey creatures.",
  "Undercommon": "The trade language of the Underdark."
};

export const invocationDescriptions = {
  "Agonizing Blast": "Add your Charisma modifier to the damage dealt by Eldritch Blast.",
  "Armor of Shadows": "Cast mage armor on yourself at will, without expending a spell slot.",
  "Beast Speech": "Cast speak with animals at will, without expending a spell slot.",
  "Beguiling Influence": "Gain proficiency in Deception and Persuasion.",
  "Book of Ancient Secrets": "Learn ritual spells from any class and cast them as rituals.",
  "Devil's Sight": "See normally in darkness, both magical and nonmagical, to a distance of 120 feet.",
  "Eldritch Sight": "Cast detect magic at will, without expending a spell slot.",
  "Eldritch Spear": "Increase the range of Eldritch Blast to 300 feet.",
  "Eyes of the Rune Keeper": "Read all writing.",
  "Fiendish Vigor": "Cast false life on yourself at will as a 1st-level spell.",
  "Gaze of Two Minds": "Use your action to touch a willing humanoid and perceive through its senses.",
  "Mask of Many Faces": "Cast disguise self at will, without expending a spell slot.",
  "Misty Visions": "Cast silent image at will, without expending a spell slot.",
  "One with Shadows": "When in dim light or darkness, use your action to become invisible until you move or take an action.",
  "Repelling Blast": "When you hit a creature with Eldritch Blast, push it up to 10 feet away.",
  "Thief of Five Fates": "Once between rests, cast bane using a warlock spell slot.",
  "Voice of the Chain Master": "Communicate telepathically with your familiar and perceive through its senses.",
  "Whispers of the Grave": "Cast speak with dead at will, without expending a spell slot."
};

export const alignmentDescriptions = {
  "Lawful Good": "Creatures can be counted on to do the right thing as expected by society. Honor, compassion, and duty.",
  "Neutral Good": "Do the best they can to help others according to their needs. No preference between law and chaos.",
  "Chaotic Good": "Act as their conscience directs with little regard for what others expect. Freedom and kindness.",
  "Lawful Neutral": "Act in accordance with law, tradition, or personal codes. Order and organization without bias.",
  "True Neutral": "Prefer to steer clear of moral questions and don't take sides. The natural world is paramount.",
  "Chaotic Neutral": "Follow their whims, holding personal freedom above all else. Anarchic and unpredictable.",
  "Lawful Evil": "Methodically take what they want, within the limits of a code of tradition, loyalty, or order.",
  "Neutral Evil": "Do whatever they can get away with, without compassion or qualms. Pure self-interest.",
  "Chaotic Evil": "Act with arbitrary violence, spurred by greed, hatred, or bloodlust. Destruction and wickedness."
};

export const subclassDescriptions = {
  // Barbarian
  "Path of the Berserker": "Untrammeled fury and reckless abandon. Enter a frenzy to make additional attacks.",
  "Path of the Totem Warrior": "Spiritual journey guided by animal spirits. Gain animal-themed powers.",
  
  // Bard
  "College of Lore": "Know something about most things. Use Cutting Words to subtract from enemy rolls.",
  "College of Valor": "Daring skalds who inspire courage. Grant combat benefits with Bardic Inspiration.",
  
  // Cleric Domains
  "Knowledge Domain": "Value learning and understanding. Gain proficiencies and read thoughts.",
  "Life Domain": "Focus on healing and vitality. Your healing spells restore extra hit points.",
  "Light Domain": "Promote truth and vigilance. Wield radiant damage and protective light.",
  "Nature Domain": "Guardians of the natural world. Charm animals and plants.",
  "Tempest Domain": "Control storms and weather. Deal maximum lightning or thunder damage.",
  "Trickery Domain": "Mischief and deception. Create illusory duplicates and become invisible.",
  "War Domain": "Watch over warriors. Make extra attacks and grant bonus to hit.",
  
  // Druid
  "Circle of the Land": "Mystics who safeguard ancient knowledge. Gain terrain-based spells and natural recovery.",
  "Circle of the Moon": "Fierce guardians who transform into powerful beasts for combat.",
  
  // Fighter
  "Champion": "Focus on raw physical power and improved critical hits.",
  "Battle Master": "Master of combat maneuvers and tactical superiority.",
  "Eldritch Knight": "Combine martial prowess with wizard spells.",
  
  // Monk
  "Way of the Open Hand": "Ultimate masters of unarmed combat. Manipulate ki to heal and protect.",
  "Way of Shadow": "Stealth and subterfuge. Teleport between shadows.",
  "Way of the Four Elements": "Harness elemental power with ki.",
  
  // Paladin
  "Oath of Devotion": "Paladins of justice, virtue, and order. Cannot be charmed.",
  "Oath of the Ancients": "Preserve life and light. Resistance to spell damage.",
  "Oath of Vengeance": "Punish wrongdoers. Gain advantage on attacks against chosen foes.",
  
  // Ranger
  "Hunter": "Master of hunting techniques. Deal extra damage and use defensive tactics.",
  "Beast Master": "Bond with an animal companion that fights alongside you.",
  
  // Rogue
  "Thief": "Master of larceny. Use items and climb with bonus actions.",
  "Assassin": "Deadly killer. Gain advantage on creatures that haven't acted and auto-crit on surprised foes.",
  "Arcane Trickster": "Blend stealth with magic. Use wizard spells and enhance mage hand.",
  
  // Sorcerer
  "Draconic Bloodline": "Magic from dragon ancestry. Increased HP, natural armor, and dragon wings.",
  "Wild Magic": "Chaotic magic that can surge unpredictably. Manipulate fate with Tides of Chaos.",
  
  // Warlock
  "The Archfey": "Pact with a fey lord. Charm and frighten with Fey Presence.",
  "The Fiend": "Pact with a devil or demon. Gain temporary HP when you kill enemies.",
  "The Great Old One": "Pact with an incomprehensible entity. Telepathy and thought reading.",
  
  // Wizard
  "School of Abjuration": "Master of protective magic. Create arcane wards.",
  "School of Evocation": "Master of destructive magic. Protect allies from your area spells."
};

export const pactBoonDescriptions = {
  "Pact of the Chain": "Gain a more powerful familiar: imp, pseudodragon, quasit, or sprite.",
  "Pact of the Blade": "Summon a magical melee weapon at will.",
  "Pact of the Tome": "Receive a Book of Shadows with three additional cantrips from any class."
};

export const fightingStyleDescriptions = {
  "Archery": "+2 bonus to attack rolls with ranged weapons.",
  "Defense": "+1 bonus to AC while wearing armor.",
  "Dueling": "+2 bonus to damage rolls when wielding a melee weapon in one hand with no other weapons.",
  "Great Weapon Fighting": "Reroll 1s and 2s on damage dice for two-handed melee weapons.",
  "Protection": "Impose disadvantage on attacks against allies within 5 feet (requires shield).",
  "Two-Weapon Fighting": "Add ability modifier to damage of the second attack when two-weapon fighting."
};

export const languagesByRace = {
  "Dragonborn": ["Common", "Draconic"],
  "Dwarf": ["Common", "Dwarvish"],
  "Elf": ["Common", "Elvish"],
  "Gnome": ["Common", "Gnomish"],
  "Half-Elf": ["Common", "Elvish"],
  "Half-Orc": ["Common", "Orc"],
  "Halfling": ["Common", "Halfling"],
  "Human": ["Common"],
  "Tiefling": ["Common", "Infernal"]
};

export const backgroundLanguages = {
  "Acolyte": 2,
  "Charlatan": 0,
  "Criminal": 0,
  "Entertainer": 0,
  "Folk Hero": 0,
  "Guild Artisan": 1,
  "Hermit": 1,
  "Noble": 1,
  "Outlander": 1,
  "Sage": 2,
  "Sailor": 0,
  "Soldier": 0,
  "Urchin": 0
};