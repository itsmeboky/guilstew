import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import ReactQuill from 'react-quill';

export default function CampaignWorldLore() {
  const urlParams = new URLSearchParams(window.location.search);
  const campaignId = urlParams.get('id');
  const [loreContent, setLoreContent] = useState("");

  const queryClient = useQueryClient();

  const { data: campaign } = useQuery({
    queryKey: ['campaign', campaignId],
    queryFn: async () => {
      const campaigns = await base44.entities.Campaign.list();
      return campaigns.find(c => c.id === campaignId);
    },
    enabled: !!campaignId
  });

  useEffect(() => {
    if (campaign?.world_lore) {
      setLoreContent(campaign.world_lore);
    }
  }, [campaign]);

  const saveLoreMutation = useMutation({
    mutationFn: (content) => base44.entities.Campaign.update(campaignId, { world_lore: content }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
    }
  });

  const handleSave = () => {
    saveLoreMutation.mutate(loreContent);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E2430] to-[#2A3441] p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold">World Lore</h1>
          <Button 
            onClick={handleSave} 
            disabled={saveLoreMutation.isPending}
            className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]"
          >
            {saveLoreMutation.isPending ? 'Saving...' : 'Save'}
          </Button>
        </div>

        <div className="bg-[#2A3441] rounded-xl p-8">
          <ReactQuill
            theme="snow"
            value={loreContent}
            onChange={setLoreContent}
            className="bg-white text-black rounded-lg"
            style={{ height: '600px', marginBottom: '50px' }}
            placeholder="Write your world's lore, history, factions, and more..."
          />
        </div>
      </div>
    </div>
  );
}