import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import ProfileCard from "@/components/profile/ProfileCard";
import FavoriteClass from "@/components/profile/FavoriteClass";
import RecentCharacters from "@/components/characters/RecentCharacters";
import AverageStatistics from "@/components/profile/AverageStatistics";
import FriendsCarousel from "@/components/friends/FriendsCarousel";
import RecentCampaigns from "@/components/campaigns/RecentCampaigns";

export default function YourProfile() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    initialData: null
  });

  const { data: characters } = useQuery({
    queryKey: ['recentCharacters'],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }, '-updated_date', 4),
    enabled: !!user,
    initialData: []
  });

  const { data: campaigns } = useQuery({
    queryKey: ['recentCampaigns'],
    queryFn: async () => {
      const allCampaigns = await base44.entities.Campaign.list('-updated_date');
      return allCampaigns.filter(c => 
        c.game_master_id === user?.id || c.player_ids?.includes(user?.id)
      ).slice(0, 5);
    },
    enabled: !!user,
    initialData: []
  });

  const { data: friends } = useQuery({
    queryKey: ['friends'],
    queryFn: async () => {
      const friendships = await base44.entities.Friend.filter({ 
        user_id: user?.id, 
        status: 'accepted' 
      });
      const friendIds = friendships.map(f => f.friend_id);
      const allUsers = await base44.entities.User.list();
      return allUsers.filter(u => friendIds.includes(u.id)).slice(0, 6);
    },
    enabled: !!user,
    initialData: []
  });

  const { data: featuredAchievements } = useQuery({
    queryKey: ['featuredAchievements'],
    queryFn: async () => {
      if (!user?.featured_achievement_ids || user.featured_achievement_ids.length === 0) {
        return [];
      }
      const allAchievements = await base44.entities.Achievement.filter({ user_id: user.id });
      return allAchievements.filter(a => user.featured_achievement_ids.includes(a.id));
    },
    enabled: !!user,
    initialData: []
  });

  return (
    <div className="relative min-h-screen">
      {/* Banner Wallpaper */}
      <div 
        className="absolute top-0 left-0 right-0 h-[33vh] bg-cover bg-center"
        style={{ 
          backgroundImage: `url(${user?.banner_url || 'https://images.unsplash.com/photo-1569003339405-ea396a5a8a90?w=1200&h=400&fit=crop'})`,
          filter: 'blur(2px)'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#1E2430]/30 to-[#1E2430]" />
      </div>

      <div className="relative z-10 px-8 pt-24 pb-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <ProfileCard user={user} showFullStats featuredAchievements={featuredAchievements} />
            <AverageStatistics characters={characters} />
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FavoriteClass favoriteClass={user?.favorite_class} iconUrl={user?.favorite_class_icon} />
              <RecentCharacters characters={characters} />
            </div>

            <FriendsCarousel friends={friends} />
            <RecentCampaigns campaigns={campaigns} />
          </div>
        </div>
      </div>
    </div>
  );
}