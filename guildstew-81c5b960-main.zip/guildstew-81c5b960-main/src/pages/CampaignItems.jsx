import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Upload, Package } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function CampaignItems() {
  const urlParams = new URLSearchParams(window.location.search);
  const campaignId = urlParams.get('id');
  const [selectedItem, setSelectedItem] = useState(null);
  const [editingItem, setEditingItem] = useState(null);

  const queryClient = useQueryClient();

  const { data: items } = useQuery({
    queryKey: ['campaignItems', campaignId],
    queryFn: () => base44.entities.CampaignItem.filter({ campaign_id: campaignId }),
    enabled: !!campaignId,
    initialData: []
  });

  const createItemMutation = useMutation({
    mutationFn: (data) => base44.entities.CampaignItem.create({ ...data, campaign_id: campaignId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignItems', campaignId] });
      setEditingItem(null);
    }
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CampaignItem.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignItems', campaignId] });
      setSelectedItem(null);
      setEditingItem(null);
    }
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id) => base44.entities.CampaignItem.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignItems', campaignId] });
      setSelectedItem(null);
    }
  });

  const handleCreateNew = () => {
    setEditingItem({ name: "", description: "", rarity: "common", type: "Item" });
  };

  const handleSave = () => {
    if (editingItem.id) {
      updateItemMutation.mutate({ id: editingItem.id, data: editingItem });
    } else {
      createItemMutation.mutate(editingItem);
    }
  };

  const handleImageUpload = async (file) => {
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setEditingItem({ ...editingItem, image_url: file_url });
  };

  const rarityColors = {
    common: "bg-gray-400",
    uncommon: "bg-green-400",
    rare: "bg-blue-400",
    very_rare: "bg-purple-400",
    legendary: "bg-orange-400",
    artifact: "bg-red-400"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E2430] to-[#2A3441] p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold">Item Shop</h1>
          <Button onClick={handleCreateNew} className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]">
            <Plus className="w-5 h-5 mr-2" />
            Create Item
          </Button>
        </div>

        {/* Item Grid */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {items.map(item => (
            <div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className="bg-[#2A3441] rounded-xl overflow-hidden cursor-pointer hover:scale-105 transition-transform"
            >
              {item.image_url ? (
                <img src={item.image_url} alt={item.name} className="w-full h-48 object-cover" />
              ) : (
                <div className="w-full h-48 bg-[#1E2430] flex items-center justify-center">
                  <Package className="w-16 h-16 text-gray-600" />
                </div>
              )}
              <div className="p-4">
                <div className={`inline-block px-2 py-1 rounded text-xs font-bold text-white mb-2 ${rarityColors[item.rarity]}`}>
                  {item.rarity?.toUpperCase()}
                </div>
                <h3 className="font-bold text-lg">{item.name}</h3>
                <p className="text-sm text-gray-400 line-clamp-2">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Item Detail Modal */}
        {(selectedItem || editingItem) && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-8">
            <div className="bg-[#2A3441] rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-8">
              {editingItem ? (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold">{editingItem.id ? 'Edit Item' : 'Create Item'}</h2>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Item Image</label>
                    {editingItem.image_url ? (
                      <img src={editingItem.image_url} alt="Item" className="w-48 h-48 rounded-lg object-cover mb-2" />
                    ) : (
                      <div className="w-48 h-48 bg-[#1E2430] rounded-lg flex items-center justify-center mb-2">
                        <Upload className="w-12 h-12 text-gray-500" />
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files[0] && handleImageUpload(e.target.files[0])}
                      className="text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Name</label>
                    <Input
                      value={editingItem.name}
                      onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                      placeholder="Item Name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Rarity</label>
                    <Select value={editingItem.rarity} onValueChange={(v) => setEditingItem({ ...editingItem, rarity: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="common">Common</SelectItem>
                        <SelectItem value="uncommon">Uncommon</SelectItem>
                        <SelectItem value="rare">Rare</SelectItem>
                        <SelectItem value="very_rare">Very Rare</SelectItem>
                        <SelectItem value="legendary">Legendary</SelectItem>
                        <SelectItem value="artifact">Artifact</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Type</label>
                    <Input
                      value={editingItem.type}
                      onChange={(e) => setEditingItem({ ...editingItem, type: e.target.value })}
                      placeholder="Weapon, Armor, Potion, etc."
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Description</label>
                    <Textarea
                      value={editingItem.description}
                      onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                      placeholder="Item description..."
                      rows={6}
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button onClick={handleSave} className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]">
                      Save Item
                    </Button>
                    <Button onClick={() => {
                      setEditingItem(null);
                      setSelectedItem(null);
                    }} variant="outline">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between items-start mb-6">
                    {selectedItem.image_url && (
                      <img src={selectedItem.image_url} alt={selectedItem.name} className="w-48 h-48 rounded-lg object-cover" />
                    )}
                    <div className="flex gap-2">
                      <Button onClick={() => setEditingItem(selectedItem)} variant="outline">
                        Edit
                      </Button>
                      <Button onClick={() => deleteItemMutation.mutate(selectedItem.id)} variant="outline" className="text-red-400">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <Button onClick={() => setSelectedItem(null)} variant="outline">
                        Close
                      </Button>
                    </div>
                  </div>

                  <div className={`inline-block px-3 py-1 rounded font-bold text-white mb-3 ${rarityColors[selectedItem.rarity]}`}>
                    {selectedItem.rarity?.toUpperCase()}
                  </div>
                  
                  <h2 className="text-3xl font-bold mb-2">{selectedItem.name}</h2>
                  <p className="text-gray-400 mb-4">{selectedItem.type}</p>
                  <p className="text-white leading-relaxed">{selectedItem.description}</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}