import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Upload } from "lucide-react";
import ReactQuill from 'react-quill';

export default function CampaignNPCs() {
  const urlParams = new URLSearchParams(window.location.search);
  const campaignId = urlParams.get('id');
  const [selectedNPC, setSelectedNPC] = useState(null);
  const [editingNPC, setEditingNPC] = useState(null);

  const queryClient = useQueryClient();

  const { data: npcs } = useQuery({
    queryKey: ['campaignNPCs', campaignId],
    queryFn: () => base44.entities.CampaignNPC.filter({ campaign_id: campaignId }),
    enabled: !!campaignId,
    initialData: []
  });

  const createNPCMutation = useMutation({
    mutationFn: (data) => base44.entities.CampaignNPC.create({ ...data, campaign_id: campaignId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignNPCs', campaignId] });
      setEditingNPC(null);
    }
  });

  const updateNPCMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CampaignNPC.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignNPCs', campaignId] });
      setSelectedNPC(null);
      setEditingNPC(null);
    }
  });

  const deleteNPCMutation = useMutation({
    mutationFn: (id) => base44.entities.CampaignNPC.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignNPCs', campaignId] });
      setSelectedNPC(null);
    }
  });

  const handleCreateNew = () => {
    setEditingNPC({ name: "", description: "", notes: "" });
  };

  const handleSave = () => {
    if (editingNPC.id) {
      updateNPCMutation.mutate({ id: editingNPC.id, data: editingNPC });
    } else {
      createNPCMutation.mutate(editingNPC);
    }
  };

  const handleImageUpload = async (file) => {
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setEditingNPC({ ...editingNPC, avatar_url: file_url });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E2430] to-[#2A3441] flex">
      {/* NPC List */}
      <div className="w-80 bg-[#2A3441] p-6 border-r border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">NPCs</h2>
          <Button onClick={handleCreateNew} size="sm" className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]">
            <Plus className="w-4 h-4" />
          </Button>
        </div>
        <div className="space-y-2">
          {npcs.map(npc => (
            <div
              key={npc.id}
              onClick={() => {
                setSelectedNPC(npc);
                setEditingNPC(null);
              }}
              className={`p-4 rounded-lg cursor-pointer transition-colors ${
                selectedNPC?.id === npc.id ? 'bg-[#37F2D1]/20 border border-[#37F2D1]' : 'bg-[#1E2430] hover:bg-[#1E2430]/70'
              }`}
            >
              <div className="flex items-center gap-3">
                {npc.avatar_url && (
                  <img src={npc.avatar_url} alt={npc.name} className="w-10 h-10 rounded-full object-cover" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{npc.name}</p>
                  {npc.description && (
                    <p className="text-sm text-gray-400 truncate">{npc.description}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* NPC Details/Editor */}
      <div className="flex-1 p-8">
        {editingNPC ? (
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-6">{editingNPC.id ? 'Edit NPC' : 'Create New NPC'}</h1>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2">Avatar</label>
                {editingNPC.avatar_url ? (
                  <img src={editingNPC.avatar_url} alt="Avatar" className="w-32 h-32 rounded-lg object-cover mb-2" />
                ) : (
                  <div className="w-32 h-32 bg-[#1E2430] rounded-lg flex items-center justify-center mb-2">
                    <Upload className="w-8 h-8 text-gray-500" />
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => e.target.files[0] && handleImageUpload(e.target.files[0])}
                  className="text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Name</label>
                <Input
                  value={editingNPC.name}
                  onChange={(e) => setEditingNPC({ ...editingNPC, name: e.target.value })}
                  placeholder="NPC Name"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Short Description</label>
                <Input
                  value={editingNPC.description}
                  onChange={(e) => setEditingNPC({ ...editingNPC, description: e.target.value })}
                  placeholder="Brief description"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Notes</label>
                <ReactQuill
                  theme="snow"
                  value={editingNPC.notes || ""}
                  onChange={(value) => setEditingNPC({ ...editingNPC, notes: value })}
                  className="bg-white text-black rounded-lg"
                  style={{ height: '400px', marginBottom: '50px' }}
                />
              </div>

              <div className="flex gap-3">
                <Button onClick={handleSave} className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]">
                  Save NPC
                </Button>
                <Button onClick={() => setEditingNPC(null)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        ) : selectedNPC ? (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                {selectedNPC.avatar_url && (
                  <img src={selectedNPC.avatar_url} alt={selectedNPC.name} className="w-20 h-20 rounded-lg object-cover" />
                )}
                <div>
                  <h1 className="text-3xl font-bold">{selectedNPC.name}</h1>
                  {selectedNPC.description && (
                    <p className="text-gray-400">{selectedNPC.description}</p>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => setEditingNPC(selectedNPC)} variant="outline">
                  Edit
                </Button>
                <Button onClick={() => deleteNPCMutation.mutate(selectedNPC.id)} variant="outline" className="text-red-400">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="bg-[#2A3441] rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Notes</h3>
              <div 
                className="prose prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: selectedNPC.notes || '<p class="text-gray-400">No notes yet</p>' }}
              />
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-400 text-xl">Select an NPC or create a new one</p>
          </div>
        )}
      </div>
    </div>
  );
}