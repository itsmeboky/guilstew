import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, UserPlus, Check, X, MessageSquare, Ban } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Friends() {
  const [searchQuery, setSearchQuery] = useState("");
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: allUsers } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: friendships } = useQuery({
    queryKey: ['friendships'],
    queryFn: async () => {
      const allFriendships = await base44.entities.Friend.list();
      return allFriendships.filter(f => 
        f.user_id === user?.id || f.friend_id === user?.id
      );
    },
    enabled: !!user,
    initialData: []
  });

  const sendRequestMutation = useMutation({
    mutationFn: async (friendId) => {
      await base44.entities.Friend.create({
        user_id: user.id,
        friend_id: friendId,
        status: 'pending'
      });
      await base44.entities.Friend.create({
        user_id: friendId,
        friend_id: user.id,
        status: 'pending'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['friendships'] });
      toast.success('Friend request sent');
    }
  });

  const acceptRequestMutation = useMutation({
    mutationFn: async (friendUserId) => {
      const userFriendship = friendships.find(f => 
        f.user_id === user.id && f.friend_id === friendUserId && f.status === 'pending'
      );
      const friendFriendship = friendships.find(f => 
        f.user_id === friendUserId && f.friend_id === user.id && f.status === 'pending'
      );

      if (userFriendship) {
        await base44.entities.Friend.update(userFriendship.id, { status: 'accepted' });
      }
      if (friendFriendship) {
        await base44.entities.Friend.update(friendFriendship.id, { status: 'accepted' });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['friendships'] });
      toast.success('Friend request accepted');
    }
  });

  const declineRequestMutation = useMutation({
    mutationFn: async (friendUserId) => {
      const userFriendship = friendships.find(f => 
        f.user_id === user.id && f.friend_id === friendUserId
      );
      const friendFriendship = friendships.find(f => 
        f.user_id === friendUserId && f.friend_id === user.id
      );

      if (userFriendship) {
        await base44.entities.Friend.delete(userFriendship.id);
      }
      if (friendFriendship) {
        await base44.entities.Friend.delete(friendFriendship.id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['friendships'] });
      toast.success('Request declined');
    }
  });

  const createDMConversation = useMutation({
    mutationFn: async (friendId) => {
      const conversations = await base44.entities.ChatConversation.list();
      const existingConvo = conversations.find(c => 
        c.type === 'dm' && 
        c.participant_ids?.includes(user.id) && 
        c.participant_ids?.includes(friendId)
      );

      if (existingConvo) {
        return existingConvo;
      }

      return await base44.entities.ChatConversation.create({
        type: 'dm',
        participant_ids: [user.id, friendId],
        last_message: '',
        last_message_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      toast.success('Chat opened! Click the chat button in bottom right.');
    }
  });
  
  const acceptedFriends = friendships
    .filter(f => f.status === 'accepted')
    .map(f => {
      const friendId = f.user_id === user?.id ? f.friend_id : f.user_id;
      const friend = allUsers.find(u => u.id === friendId);
      return friend ? { ...friend, friendshipId: f.id } : null;
    })
    .filter(f => f !== null)
    .filter((friend, index, self) => 
      index === self.findIndex(f => f.id === friend.id)
    );

  const pendingRequests = friendships
    .filter(f => f.friend_id === user?.id && f.status === 'pending')
    .map(f => {
      const friend = allUsers.find(u => u.id === f.user_id);
      return friend ? { ...friend, friendshipId: f.id, senderId: f.user_id } : null;
    })
    .filter(f => f !== null);

  const sentRequests = friendships
    .filter(f => f.user_id === user?.id && f.status === 'pending')
    .map(f => {
      const friend = allUsers.find(u => u.id === f.friend_id);
      return friend ? { ...friend, friendshipId: f.id, recipientId: f.friend_id } : null;
    })
    .filter(f => f !== null);

  const blockedUsers = friendships
    .filter(f => f.user_id === user?.id && f.status === 'blocked')
    .map(f => allUsers.find(u => u.id === f.friend_id))
    .filter(f => f);

  const allFriendUserIds = friendships.map(f => 
    f.user_id === user?.id ? f.friend_id : f.user_id
  );
  
  const searchResults = allUsers.filter(u => 
    u.id !== user?.id &&
    !allFriendUserIds.includes(u.id) &&
    (u.username?.toLowerCase().includes(searchQuery.toLowerCase()) || 
     u.email?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const FriendCard = ({ friend, actions }) => (
    <div className="bg-[#2A3441] rounded-xl p-4 flex items-center gap-4">
      <Link to={createPageUrl("UserProfile") + `?id=${friend.id}`} className="relative">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 overflow-hidden hover:ring-2 hover:ring-[#37F2D1] transition-all">
          {friend.avatar_url && <img src={friend.avatar_url} alt={friend.username} className="w-full h-full object-cover" />}
        </div>
        {friend.online_status === 'online' && (
          <div className="absolute bottom-0 right-0 w-4 h-4 bg-[#37F2D1] rounded-full border-2 border-[#2A3441]" />
        )}
      </Link>
      <div className="flex-1">
        <Link to={createPageUrl("UserProfile") + `?id=${friend.id}`}>
          <h3 className="font-bold text-white hover:text-[#37F2D1] transition-colors">{friend.username || 'User'}</h3>
        </Link>
        <p className="text-sm text-gray-400">{friend.email}</p>
        {friend.tagline && <p className="text-xs text-gray-500 italic">{friend.tagline}</p>}
      </div>
      <div className="flex gap-2">
        {actions}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Friends</h1>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="bg-[#2A3441]">
            <TabsTrigger value="all" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              All Friends ({acceptedFriends.length})
            </TabsTrigger>
            <TabsTrigger value="pending" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              Requests ({pendingRequests.length})
            </TabsTrigger>
            <TabsTrigger value="search" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              Add Friends
            </TabsTrigger>
            <TabsTrigger value="blocked" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              Blocked
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <ScrollArea className="h-[600px]">
              <div className="space-y-3">
                {acceptedFriends.map(friend => (
                  <FriendCard
                    key={friend.id}
                    friend={friend}
                    actions={
                      <>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="text-[#37F2D1] hover:text-[#2dd9bd]"
                          onClick={() => createDMConversation.mutate(friend.id)}
                          disabled={createDMConversation.isPending}
                        >
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="text-red-400 hover:text-red-300"
                          onClick={() => declineRequestMutation.mutate(friend.id)}
                        >
                          <Ban className="w-4 h-4" />
                        </Button>
                      </>
                    }
                  />
                ))}
                {acceptedFriends.length === 0 && (
                  <p className="text-center text-gray-500 py-12">No friends yet. Start adding friends!</p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="pending">
            <ScrollArea className="h-[600px]">
              <div className="space-y-6">
                {pendingRequests.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Incoming Requests</h3>
                    <div className="space-y-3">
                      {pendingRequests.map(friend => (
                        <FriendCard
                          key={friend.id}
                          friend={friend}
                          actions={
                            <>
                              <Button 
                                size="icon" 
                                className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]"
                                onClick={() => acceptRequestMutation.mutate(friend.senderId)}
                              >
                                <Check className="w-4 h-4" />
                              </Button>
                              <Button 
                                size="icon" 
                                variant="ghost" 
                                className="text-red-400"
                                onClick={() => declineRequestMutation.mutate(friend.senderId)}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </>
                          }
                        />
                      ))}
                    </div>
                  </div>
                )}

                {sentRequests.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Sent Requests</h3>
                    <div className="space-y-3">
                      {sentRequests.map(friend => (
                        <FriendCard
                          key={friend.id}
                          friend={friend}
                          actions={
                            <Button 
                              size="sm" 
                              variant="ghost"
                              className="text-red-400 hover:text-red-300"
                              onClick={() => declineRequestMutation.mutate(friend.recipientId)}
                            >
                              Cancel Request
                            </Button>
                          }
                        />
                      ))}
                    </div>
                  </div>
                )}

                {pendingRequests.length === 0 && sentRequests.length === 0 && (
                  <p className="text-center text-gray-500 py-12">No pending requests</p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="search">
            <div className="space-y-4">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search by username or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 text-white"
                  />
                </div>
              </div>

              <ScrollArea className="h-[540px]">
                <div className="space-y-3">
                  {searchQuery.length > 0 ? (
                    searchResults.map(friend => (
                      <FriendCard
                        key={friend.id}
                        friend={friend}
                        actions={
                          <Button 
                            className="bg-green-600 hover:bg-green-700 text-white gap-2 px-6"
                            onClick={() => sendRequestMutation.mutate(friend.id)}
                            disabled={sendRequestMutation.isPending}
                          >
                            <UserPlus className="w-4 h-4" />
                            Add Friend
                          </Button>
                        }
                      />
                    ))
                  ) : (
                    <p className="text-center text-gray-500 py-12">Search for users to add as friends</p>
                  )}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="blocked">
            <ScrollArea className="h-[600px]">
              <div className="space-y-3">
                {blockedUsers.map(friend => (
                  <FriendCard
                    key={friend.id}
                    friend={friend}
                    actions={
                      <Button 
                        size="sm"
                        variant="outline"
                        onClick={() => declineRequestMutation.mutate(friend.id)}
                      >
                        Unblock
                      </Button>
                    }
                  />
                ))}
                {blockedUsers.length === 0 && (
                  <p className="text-center text-gray-500 py-12">No blocked users</p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}