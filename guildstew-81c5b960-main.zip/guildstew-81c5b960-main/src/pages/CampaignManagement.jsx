import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UserPlus, Shield, User, AlertTriangle, UserX, Crown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function CampaignManagement() {
  const urlParams = new URLSearchParams(window.location.search);
  const campaignId = urlParams.get('id');

  const [addPlayerEmail, setAddPlayerEmail] = useState("");
  const [addPlayerRole, setAddPlayerRole] = useState("player");
  const [transferGMDialog, setTransferGMDialog] = useState(false);
  const [selectedNewGM, setSelectedNewGM] = useState(null);
  const [warnDialog, setWarnDialog] = useState({ open: false, userId: null, userName: "" });
  const [warnReason, setWarnReason] = useState("");

  const queryClient = useQueryClient();

  const { data: campaign } = useQuery({
    queryKey: ['campaign', campaignId],
    queryFn: async () => {
      const campaigns = await base44.entities.Campaign.list();
      return campaigns.find(c => c.id === campaignId);
    },
    enabled: !!campaignId
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: allUsers } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const isGM = campaign?.game_master_id === user?.id;
  const isCoDM = campaign?.co_dm_ids?.includes(user?.id);
  const canManage = isGM || isCoDM;

  const addPlayerMutation = useMutation({
    mutationFn: async ({ email, role }) => {
      const userToAdd = allUsers.find(u => u.email === email);
      if (!userToAdd) throw new Error("User not found");

      const updates = {};
      if (role === "co-dm") {
        updates.co_dm_ids = [...(campaign.co_dm_ids || []), userToAdd.id];
      } else {
        updates.player_ids = [...(campaign.player_ids || []), userToAdd.id];
      }
      return base44.entities.Campaign.update(campaignId, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
      setAddPlayerEmail("");
      setAddPlayerRole("player");
    }
  });

  const removePlayerMutation = useMutation({
    mutationFn: async (userId) => {
      const updates = {
        player_ids: campaign.player_ids.filter(id => id !== userId),
        co_dm_ids: (campaign.co_dm_ids || []).filter(id => id !== userId)
      };
      return base44.entities.Campaign.update(campaignId, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
    }
  });

  const kickPlayerMutation = useMutation({
    mutationFn: async (userId) => {
      const updates = {
        player_ids: campaign.player_ids.filter(id => id !== userId),
        co_dm_ids: (campaign.co_dm_ids || []).filter(id => id !== userId),
        kicked_players: [...(campaign.kicked_players || []), userId]
      };
      return base44.entities.Campaign.update(campaignId, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
    }
  });

  const warnPlayerMutation = useMutation({
    mutationFn: async ({ userId, reason }) => {
      const warnings = campaign.player_warnings || {};
      warnings[userId] = [...(warnings[userId] || []), {
        reason,
        date: new Date().toISOString(),
        issued_by: user.id
      }];
      return base44.entities.Campaign.update(campaignId, { player_warnings: warnings });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
      setWarnDialog({ open: false, userId: null, userName: "" });
      setWarnReason("");
    }
  });

  const transferGMMutation = useMutation({
    mutationFn: async (newGMId) => {
      return base44.entities.Campaign.update(campaignId, {
        game_master_id: newGMId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
      setTransferGMDialog(false);
      setSelectedNewGM(null);
    }
  });

  const handleAddPlayer = () => {
    if (addPlayerEmail.trim()) {
      addPlayerMutation.mutate({ email: addPlayerEmail.trim(), role: addPlayerRole });
    }
  };

  const getUserById = (userId) => allUsers.find(u => u.id === userId);

  const allCampaignUsers = [
    ...(campaign?.player_ids || []),
    ...(campaign?.co_dm_ids || [])
  ];

  if (!campaign || !user) {
    return <div className="p-8 text-white">Loading...</div>;
  }

  if (!canManage) {
    return <div className="p-8 text-white">You don't have permission to manage this campaign.</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E2430] to-[#2A3441] p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Campaign Management</h1>
        <p className="text-gray-400 mb-8">{campaign.title}</p>

        {/* Current GM */}
        <div className="bg-[#2A3441] rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Crown className="w-6 h-6 text-yellow-400" />
              Game Master
            </h2>
            {isGM && (
              <Button
                onClick={() => setTransferGMDialog(true)}
                variant="outline"
                size="sm"
              >
                Transfer GM Role
              </Button>
            )}
          </div>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-yellow-400/20 rounded-full flex items-center justify-center">
              <Crown className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <p className="font-semibold text-white">{getUserById(campaign.game_master_id)?.full_name || "Unknown"}</p>
              <p className="text-sm text-gray-400">{getUserById(campaign.game_master_id)?.email}</p>
            </div>
          </div>
        </div>

        {/* Add Player */}
        <div className="bg-[#2A3441] rounded-xl p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <UserPlus className="w-6 h-6" />
            Add Player
          </h2>
          <div className="flex gap-3">
            <Input
              placeholder="Player email address"
              value={addPlayerEmail}
              onChange={(e) => setAddPlayerEmail(e.target.value)}
              className="flex-1"
            />
            <Select value={addPlayerRole} onValueChange={setAddPlayerRole}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="player">Player</SelectItem>
                <SelectItem value="co-dm">Co-DM</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={handleAddPlayer}
              disabled={!addPlayerEmail.trim() || addPlayerMutation.isPending}
              className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]"
            >
              Add
            </Button>
          </div>
        </div>

        {/* Co-DMs */}
        {campaign.co_dm_ids && campaign.co_dm_ids.length > 0 && (
          <div className="bg-[#2A3441] rounded-xl p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Shield className="w-6 h-6 text-[#37F2D1]" />
              Co-DMs
            </h2>
            <div className="space-y-3">
              {campaign.co_dm_ids.map(userId => {
                const coDM = getUserById(userId);
                if (!coDM) return null;
                return (
                  <div key={userId} className="flex items-center justify-between bg-[#1E2430] rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#37F2D1]/20 rounded-full flex items-center justify-center">
                        <Shield className="w-5 h-5 text-[#37F2D1]" />
                      </div>
                      <div>
                        <p className="font-semibold">{coDM.full_name}</p>
                        <p className="text-sm text-gray-400">{coDM.email}</p>
                      </div>
                    </div>
                    {isGM && (
                      <Button
                        onClick={() => removePlayerMutation.mutate(userId)}
                        variant="outline"
                        size="sm"
                      >
                        Remove Co-DM
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Players */}
        <div className="bg-[#2A3441] rounded-xl p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <User className="w-6 h-6" />
            Players
          </h2>
          {campaign.player_ids && campaign.player_ids.length > 0 ? (
            <div className="space-y-3">
              {campaign.player_ids.map(userId => {
                const player = getUserById(userId);
                if (!player) return null;
                const warnings = (campaign.player_warnings || {})[userId] || [];
                return (
                  <div key={userId} className="flex items-center justify-between bg-[#1E2430] rounded-lg p-4">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold">{player.full_name}</p>
                          {warnings.length > 0 && (
                            <Badge variant="destructive" className="text-xs">
                              {warnings.length} warning{warnings.length > 1 ? 's' : ''}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-400">{player.email}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => setWarnDialog({ open: true, userId, userName: player.full_name })}
                        variant="outline"
                        size="sm"
                        className="text-yellow-400"
                      >
                        <AlertTriangle className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => kickPlayerMutation.mutate(userId)}
                        variant="outline"
                        size="sm"
                        className="text-red-400"
                      >
                        <UserX className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-400 text-center py-8">No players added yet</p>
          )}
        </div>
      </div>

      {/* Transfer GM Dialog */}
      <Dialog open={transferGMDialog} onOpenChange={setTransferGMDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transfer Game Master Role</DialogTitle>
            <DialogDescription>
              Select a player or co-DM to become the new Game Master. You will become a regular player.
            </DialogDescription>
          </DialogHeader>
          <Select value={selectedNewGM} onValueChange={setSelectedNewGM}>
            <SelectTrigger>
              <SelectValue placeholder="Select new GM" />
            </SelectTrigger>
            <SelectContent>
              {allCampaignUsers.map(userId => {
                const u = getUserById(userId);
                if (!u) return null;
                return (
                  <SelectItem key={userId} value={userId}>
                    {u.full_name} ({u.email})
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTransferGMDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => transferGMMutation.mutate(selectedNewGM)}
              disabled={!selectedNewGM || transferGMMutation.isPending}
              className="bg-yellow-400 hover:bg-yellow-500 text-[#1E2430]"
            >
              Transfer GM Role
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Warn Player Dialog */}
      <Dialog open={warnDialog.open} onOpenChange={(open) => setWarnDialog({ ...warnDialog, open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Issue Warning to {warnDialog.userName}</DialogTitle>
            <DialogDescription>
              Provide a reason for this warning. The player will be notified.
            </DialogDescription>
          </DialogHeader>
          <Input
            placeholder="Reason for warning"
            value={warnReason}
            onChange={(e) => setWarnReason(e.target.value)}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setWarnDialog({ open: false, userId: null, userName: "" })}>
              Cancel
            </Button>
            <Button
              onClick={() => warnPlayerMutation.mutate({ userId: warnDialog.userId, reason: warnReason })}
              disabled={!warnReason.trim() || warnPlayerMutation.isPending}
              className="bg-yellow-400 hover:bg-yellow-500 text-[#1E2430]"
            >
              Issue Warning
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}