import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import ProfileCard from "@/components/profile/ProfileCard";
import FavoriteClass from "@/components/profile/FavoriteClass";
import RecentCharacters from "@/components/characters/RecentCharacters";
import AverageStatistics from "@/components/profile/AverageStatistics";
import FriendsCarousel from "@/components/friends/FriendsCarousel";
import RecentCampaigns from "@/components/campaigns/RecentCampaigns";

export default function UserProfile() {
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get('id');

  const { data: allUsers } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const user = allUsers.find(u => u.id === userId);

  const { data: characters } = useQuery({
    queryKey: ['userCharacters', userId],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }, '-updated_date', 4),
    enabled: !!user,
    initialData: []
  });

  const { data: campaigns } = useQuery({
    queryKey: ['userCampaigns', userId],
    queryFn: async () => {
      const allCampaigns = await base44.entities.Campaign.list('-updated_date');
      return allCampaigns.filter(c => 
        c.game_master_id === userId || c.player_ids?.includes(userId)
      ).slice(0, 5);
    },
    enabled: !!userId,
    initialData: []
  });

  const { data: friends } = useQuery({
    queryKey: ['userFriends', userId],
    queryFn: async () => {
      const friendships = await base44.entities.Friend.filter({ 
        user_id: userId, 
        status: 'accepted' 
      });
      const friendIds = friendships.map(f => f.friend_id);
      const allUsers = await base44.entities.User.list();
      return allUsers.filter(u => friendIds.includes(u.id)).slice(0, 6);
    },
    enabled: !!userId,
    initialData: []
  });

  const { data: featuredAchievements } = useQuery({
    queryKey: ['userFeaturedAchievements', userId],
    queryFn: async () => {
      if (!user?.featured_achievement_ids || user.featured_achievement_ids.length === 0) {
        return [];
      }
      const allAchievements = await base44.entities.Achievement.filter({ user_id: userId });
      return allAchievements.filter(a => user.featured_achievement_ids.includes(a.id));
    },
    enabled: !!user,
    initialData: []
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-400">Loading profile...</p>
      </div>
    );
  }

  return (
    <div className="relative">
      <div 
        className="h-48 bg-cover bg-center relative"
        style={{ backgroundImage: user?.banner_url || 'url(https://images.unsplash.com/photo-1569003339405-ea396a5a8a90?w=1200&h=400&fit=crop)' }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#1E2430]" />
      </div>

      <div className="px-8 -mt-16 relative z-10 pb-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <ProfileCard user={user} showFullStats featuredAchievements={featuredAchievements} />
            <AverageStatistics characters={characters} />
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FavoriteClass favoriteClass={user?.favorite_class} iconUrl={user?.favorite_class_icon} />
              <RecentCharacters characters={characters} />
            </div>

            <FriendsCarousel friends={friends} />
            <RecentCampaigns campaigns={campaigns} />
          </div>
        </div>
      </div>
    </div>
  );
}