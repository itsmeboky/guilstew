
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Upload } from "lucide-react";
import ReactQuill from 'react-quill';

export default function CampaignMaps() {
  const urlParams = new URLSearchParams(window.location.search);
  const campaignId = urlParams.get('id');
  const [selectedMap, setSelectedMap] = useState(null);
  const [editingMap, setEditingMap] = useState(null);

  const queryClient = useQueryClient();

  const { data: maps } = useQuery({
    queryKey: ['campaignMaps', campaignId],
    queryFn: () => base44.entities.CampaignMap.filter({ campaign_id: campaignId }),
    enabled: !!campaignId,
    initialData: []
  });

  const createMapMutation = useMutation({
    mutationFn: (data) => base44.entities.CampaignMap.create({ ...data, campaign_id: campaignId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignMaps', campaignId] });
      setEditingMap(null);
    }
  });

  const updateMapMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CampaignMap.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignMaps', campaignId] });
      setSelectedMap(null);
      setEditingMap(null);
    }
  });

  const deleteMapMutation = useMutation({
    mutationFn: (id) => base44.entities.CampaignMap.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaignMaps', campaignId] });
      setSelectedMap(null);
    }
  });

  const handleCreateNew = () => {
    setEditingMap({ name: "", image_url: "", notes: "" });
  };

  const handleSave = () => {
    if (editingMap.id) {
      updateMapMutation.mutate({ id: editingMap.id, data: editingMap });
    } else {
      createMapMutation.mutate(editingMap);
    }
  };

  const handleImageUpload = async (file) => {
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setEditingMap({ ...editingMap, image_url: file_url });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E2430] to-[#2A3441] p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold">Campaign Maps</h1>
          <Button onClick={handleCreateNew} className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]">
            <Plus className="w-5 h-5 mr-2" />
            Add Map
          </Button>
        </div>

        {/* Maps Grid */}
        <div className="grid grid-cols-3 gap-6 mb-8">
          {maps.map(map => (
            <div
              key={map.id}
              onClick={() => setSelectedMap(map)}
              className="bg-[#2A3441] rounded-xl overflow-hidden cursor-pointer hover:scale-105 transition-transform"
            >
              <img src={map.image_url} alt={map.name} className="w-full h-64 object-cover" />
              <div className="p-4">
                <h3 className="font-bold text-lg">{map.name}</h3>
              </div>
            </div>
          ))}
        </div>

        {/* Map Detail Modal */}
        {(selectedMap || editingMap) && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-8">
            <div className="bg-[#2A3441] rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto p-8">
              {editingMap ? (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold">{editingMap.id ? 'Edit Map' : 'Add Map'}</h2>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Map Image</label>
                    {editingMap.image_url ? (
                      <img src={editingMap.image_url} alt="Map" className="w-full max-h-96 rounded-lg object-contain mb-2 bg-[#1E2430]" />
                    ) : (
                      <div className="w-full h-64 bg-[#1E2430] rounded-lg flex items-center justify-center mb-2">
                        <Upload className="w-16 h-16 text-gray-500" />
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files[0] && handleImageUpload(e.target.files[0])}
                      className="text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Map Name</label>
                    <Input
                      value={editingMap.name}
                      onChange={(e) => setEditingMap({ ...editingMap, name: e.target.value })}
                      placeholder="Map Name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Notes</label>
                    <ReactQuill
                      theme="snow"
                      value={editingMap.notes || ""}
                      onChange={(value) => setEditingMap({ ...editingMap, notes: value })}
                      className="bg-white text-black rounded-lg"
                      style={{ height: '300px', marginBottom: '50px' }}
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button onClick={handleSave} className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]">
                      Save Map
                    </Button>
                    <Button onClick={() => {
                      setEditingMap(null);
                      setSelectedMap(null);
                    }} variant="outline">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between items-start mb-6">
                    <h2 className="text-3xl font-bold">{selectedMap.name}</h2>
                    <div className="flex gap-2">
                      <Button onClick={() => setEditingMap(selectedMap)} variant="outline">
                        Edit
                      </Button>
                      <Button onClick={() => deleteMapMutation.mutate(selectedMap.id)} variant="outline" className="text-red-400">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <Button onClick={() => setSelectedMap(null)} variant="outline">
                        Close
                      </Button>
                    </div>
                  </div>

                  <img src={selectedMap.image_url} alt={selectedMap.name} className="w-full max-h-96 rounded-lg object-contain mb-6 bg-[#1E2430]" />

                  {selectedMap.notes && (
                    <div className="bg-[#1E2430] rounded-xl p-6">
                      <h3 className="text-xl font-bold mb-4">Notes</h3>
                      <div 
                        className="prose prose-invert max-w-none"
                        dangerouslySetInnerHTML={{ __html: selectedMap.notes }}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
