
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit, Trash2, User, Shield, Heart, Zap, Eye, Footprints, Swords } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import CreateCharacterDialog from "@/components/characters/CreateCharacterDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  classFeatureDescriptions,
  languageDescriptions,
  invocationDescriptions,
  alignmentDescriptions,
  subclassDescriptions,
  pactBoonDescriptions,
  fightingStyleDescriptions
} from "@/components/dnd5e/featureDescriptions";
import { classHitDice } from "@/components/dnd5e/characterCalculations";
import { spellDetails } from "@/components/dnd5e/spellData";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const skillAbilityMap = {
  "Athletics": "Str",
  "Acrobatics": "Dex", "Sleight of Hand": "Dex", "Stealth": "Dex",
  "Arcana": "Int", "History": "Int", "Investigation": "Int", "Nature": "Int", "Religion": "Int",
  "Animal Handling": "Wis", "Insight": "Wis", "Medicine": "Wis", "Perception": "Wis", "Survival": "Wis",
  "Deception": "Cha", "Intimidation": "Cha", "Performance": "Cha", "Persuasion": "Cha"
};

const skillAbilityKeys = {
  "Athletics": "str",
  "Acrobatics": "dex", "Sleight of Hand": "dex", "Stealth": "dex",
  "Arcana": "int", "History": "int", "Investigation": "int", "Nature": "int", "Religion": "int",
  "Animal Handling": "wis", "Insight": "wis", "Medicine": "wis", "Perception": "wis", "Survival": "wis",
  "Deception": "cha", "Intimidation": "cha", "Performance": "cha", "Persuasion": "cha"
};

const allSkills = [
  "Athletics",
  "Acrobatics", "Sleight of Hand", "Stealth",
  "Arcana", "History", "Investigation", "Nature", "Religion",
  "Animal Handling", "Insight", "Medicine", "Perception", "Survival",
  "Deception", "Intimidation", "Performance", "Persuasion"
];

const backgroundInfo = {
  "Acolyte": { feature: "Shelter of the Faithful", description: "You command the respect of those who share your faith, and you can perform religious ceremonies. You and your companions can receive free healing and care at temples, shrines, or other established presences of your faith." },
  "Charlatan": { feature: "False Identity", description: "You have created a second identity with documentation, established acquaintances, and disguises that allow you to assume that persona." },
  "Criminal": { feature: "Criminal Contact", description: "You have a reliable contact who acts as your liaison to a network of other criminals. You know how to get messages to and from your contact." },
  "Entertainer": { feature: "By Popular Demand", description: "You can always find a place to perform, where you receive free lodging and food of a modest or comfortable standard." },
  "Folk Hero": { feature: "Rustic Hospitality", description: "Since you come from the ranks of the common folk, you fit in among them with ease. You can find a place to hide, rest, or recuperate among other commoners." },
  "Guild Artisan": { feature: "Guild Membership", description: "As an established member of a guild, you can rely on certain benefits that membership provides. Your fellow guild members will provide you with lodging and food if necessary." },
  "Hermit": { feature: "Discovery", description: "The quiet seclusion of your extended hermitage gave you access to a unique and powerful discovery." },
  "Noble": { feature: "Position of Privilege", description: "Thanks to your noble birth, people are inclined to think the best of you. You are welcome in high society, and people assume you have the right to be wherever you are." },
  "Outlander": { feature: "Wanderer", description: "You have an excellent memory for maps and geography, and you can always recall the general layout of terrain, settlements, and other features around you." },
  "Sage": { feature: "Researcher", description: "When you attempt to learn or recall a piece of lore, if you do not know that information, you often know where and from whom you can obtain it." },
  "Sailor": { feature: "Ship's Passage", description: "When you need to, you can secure free passage on a sailing ship for yourself and your adventuring companions." },
  "Soldier": { feature: "Military Rank", description: "You have a military rank from your career as a soldier. Soldiers loyal to your former military organization still recognize your authority and influence." },
  "Urchin": { feature: "City Secrets", description: "You know the secret patterns and flow to cities and can find passages through the urban sprawl that others would miss. You can move through cities twice as fast as normal." }
};

const raceInfo = {
  "Dragonborn": { creatureType: "Humanoid", size: "Medium", features: ["Breath Weapon", "Damage Resistance", "Darkvision"] },
  "Elf": { creatureType: "Humanoid", size: "Medium", features: ["Darkvision", "Fey Ancestry", "Trance"] },
  "Dwarf": { creatureType: "Humanoid", size: "Medium", features: ["Darkvision", "Dwarven Resilience", "Stonecunning"] },
  "Human": { creatureType: "Humanoid", size: "Medium", features: ["Versatile", "Extra Skill"] },
  "Halfling": { creatureType: "Humanoid", size: "Small", features: ["Lucky", "Brave", "Nimble"] },
  "Tiefling": { creatureType: "Humanoid", size: "Medium", features: ["Darkvision", "Hellish Resistance", "Infernal Legacy"] },
  "Half-Elf": { creatureType: "Humanoid", size: "Medium", features: ["Darkvision", "Fey Ancestry", "Skill Versatility"] },
  "Half-Orc": { creatureType: "Humanoid", size: "Medium", features: ["Darkvision", "Relentless Endurance", "Savage Attacks"] },
  "Gnome": { creatureType: "Humanoid", size: "Small", features: ["Darkvision", "Gnome Cunning"] }
};

const featureDescriptions = {
  "Breath Weapon": "Use your action to exhale destructive energy based on your draconic ancestry. Each creature in the area must make a saving throw, taking 2d6 damage on a failed save and half on a success.",
  "Damage Resistance": "You have resistance to the damage type associated with your draconic ancestry.",
  "Darkvision": "You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray.",
  "Fey Ancestry": "You have advantage on saving throws against being charmed, and magic can't put you to sleep.",
  "Trance": "Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day.",
  "Dwarven Resilience": "You have advantage on saving throws against poison, and you have resistance against poison damage.",
  "Stonecunning": "Whenever you make an Intelligence (History) check related to the origin of stonework, you are considered proficient in the History skill and add double your proficiency bonus to the check.",
  "Versatile": "You gain a +1 bonus to all ability scores.",
  "Extra Skill": "You gain proficiency in one skill of your choice.",
  "Lucky": "When you roll a 1 on an attack roll, ability check, or saving throw, you can reroll the die and must use the new roll.",
  "Brave": "You have advantage on saving throws against being frightened.",
  "Nimble": "You can move through the space of any creature that is of a size larger than yours.",
  "Hellish Resistance": "You have resistance to fire damage.",
  "Infernal Legacy": "You know the thaumaturgy cantrip. When you reach 3rd level, you can cast hellish rebuke once per long rest. When you reach 5th level, you can cast darkness once per long rest.",
  "Skill Versatility": "You gain proficiency in two skills of your choice.",
  "Relentless Endurance": "When you are reduced to 0 hit points but not killed outright, you can drop to 1 hit point instead. You can't use this feature again until you finish a long rest.",
  "Savage Attacks": "When you score a critical hit with a melee weapon attack, you can roll one of the weapon's damage dice one additional time and add it to the extra damage of the critical hit.",
  "Gnome Cunning": "You have advantage on all Intelligence, Wisdom, and Charisma saving throws against magic."
};

const classFeatureNames = {
  "Barbarian": ["Rage", "Unarmored Defense", "Reckless Attack", "Danger Sense"],
  "Bard": ["Spellcasting", "Bardic Inspiration", "Jack of All Trades", "Song of Rest"],
  "Cleric": ["Spellcasting", "Divine Domain", "Channel Divinity"],
  "Druid": ["Druidic", "Spellcasting", "Wild Shape"],
  "Fighter": ["Fighting Style", "Second Wind", "Action Surge"],
  "Monk": ["Unarmored Defense", "Martial Arts", "Ki", "Unarmored Movement"],
  "Paladin": ["Divine Sense", "Lay on Hands", "Divine Smite"],
  "Ranger": ["Favored Enemy", "Natural Explorer", "Spellcasting"],
  "Rogue": ["Expertise", "Sneak Attack", "Thieves' Cant", "Cunning Action"],
  "Sorcerer": ["Spellcasting", "Sorcerous Origin", "Font of Magic", "Metamagic"],
  "Warlock": ["Otherworldly Patron", "Pact Magic", "Eldritch Invocations", "Pact Boon"],
  "Wizard": ["Spellcasting", "Arcane Recovery", "Arcane Tradition"]
};

const statDescriptions = {
  "Armor Class": "Your Armor Class (AC) represents how hard you are to hit in combat. Higher AC means attacks are less likely to land.",
  "Initiative": "Your Initiative bonus determines your place in the turn order during combat. Higher initiative means you act sooner.",
  "Speed": "Your Speed is the distance you can move on your turn in feet. Most characters can move 30 feet per turn.",
  "Hit Points": "Hit Points (HP) represent your health and vitality. When you reach 0 HP, you fall unconscious and begin making death saving throws.",
  "Hit Dice": "Hit Dice are used to recover hit points during short rests. You have a number of Hit Dice equal to your character level.",
  "Proficiency Bonus": "Your Proficiency Bonus is added to attack rolls, ability checks, and saving throws you're proficient in. It increases as you level up.",
  "Passive Perception": "Your Passive Perception is used when the DM wants to secretly determine if you notice something. It equals 10 + your Wisdom (Perception) modifier."
};

export default function CharacterLibrary() {
  const navigate = useNavigate();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedCharacter, setSelectedCharacter] = useState(null);
  const [hoveredCharacterId, setHoveredCharacterId] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [characterToDelete, setCharacterToDelete] = useState(null);
  const [activeTab, setActiveTab] = useState("stats");
  const [hoveredItem, setHoveredItem] = useState(null);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    initialData: null
  });

  const { data: characters } = useQuery({
    queryKey: ['allCharacters'],
    queryFn: () => base44.entities.Character.filter({ created_by: user?.email }, '-last_played'),
    enabled: !!user,
    initialData: []
  });

  const deleteCharacterMutation = useMutation({
    mutationFn: (id) => base44.entities.Character.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allCharacters'] });
      if (selectedCharacter?.id === characterToDelete?.id) {
        setSelectedCharacter(characters[0] || null);
      }
      setDeleteDialogOpen(false);
      setCharacterToDelete(null);
    }
  });

  React.useEffect(() => {
    if (characters.length > 0 && !selectedCharacter) {
      setSelectedCharacter(characters[0]);
    }
  }, [characters, selectedCharacter]);

  // handleEditClick and handleDeleteClick are now inlined for the right panel buttons
  // and removed from the left panel character card logic.

  const calculateModifier = (score) => {
    const mod = Math.floor((score - 10) / 2);
    return mod >= 0 ? `+${mod}` : `${mod}`;
  };

  const getModifierValue = (score) => {
    return Math.floor((score - 10) / 2);
  };

  const getSavingThrowModifier = (abilityKey) => {
    if (!selectedCharacter?.attributes) return "+0";
    const baseMod = getModifierValue(selectedCharacter.attributes[abilityKey]);
    const profBonus = selectedCharacter.proficiency_bonus || 2;

    const savingThrows = selectedCharacter.saving_throws || {};
    const isProficient = savingThrows[abilityKey];

    const totalMod = isProficient ? baseMod + profBonus : baseMod;
    return totalMod >= 0 ? `+${totalMod}` : `${totalMod}`;
  };

  const getSkillModifier = (skillName) => {
    if (!selectedCharacter?.attributes) return "+0";
    
    const abilityKey = skillAbilityKeys[skillName];
    const baseMod = getModifierValue(selectedCharacter.attributes[abilityKey]);
    const profBonus = selectedCharacter.proficiency_bonus || 2;
    
    const skills = selectedCharacter.skills || {};
    const expertise = selectedCharacter.expertise || [];
    
    const isProficient = skills[skillName];
    const hasExpertise = expertise.includes(skillName);
    
    let totalMod = baseMod;
    if (hasExpertise) {
      totalMod += (profBonus * 2);
    } else if (isProficient) {
      totalMod += profBonus;
    }
    
    return totalMod >= 0 ? `+${totalMod}` : `${totalMod}`;
  };

  const classInfo = selectedCharacter ? raceInfo[selectedCharacter.race] : null;
  const bgInfo = selectedCharacter ? backgroundInfo[selectedCharacter.background] : null;

  return (
    <div
      className="min-h-screen flex relative"
      style={{
        backgroundImage: 'url(https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6917dd35b600199681c5b960/767199510_ezgif2.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <div className="absolute inset-0 bg-white/30" />

      {/* Left Sidebar - Character List */}
      <div className="w-[420px] p-6 flex flex-col relative z-10" style={{
        background: 'linear-gradient(to right, rgba(30, 36, 48, 0.7), rgba(30, 36, 48, 0.95))'
      }}>
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-white">Character Library</h2>
          <div className="w-16 h-0.5 bg-[#FF5722] mx-auto mt-2" />
        </div>

        <div className="flex-1 overflow-y-auto mb-6 px-2" style={{ paddingTop: '25px' }}>
          <div className="grid grid-cols-3 gap-4">
            {characters.map((character) => {
              return (
                <div
                  key={character.id}
                  className="relative group cursor-pointer"
                  onClick={() => setSelectedCharacter(character)}
                >
                  <div
                    className={`aspect-square rounded-lg overflow-hidden transition-all ${
                      selectedCharacter?.id === character.id
                        ? 'ring-4 ring-[#37F2D1]'
                        : 'ring-2 ring-gray-600 hover:ring-[#FF5722]'
                    }`}
                  >
                    {character.profile_avatar_url ? (
                      <img
                        src={character.profile_avatar_url}
                        alt={character.name}
                        className="w-full h-full"
                        style={{
                          objectFit: 'cover',
                          objectPosition: 'center',
                          transform: character.profile_position && character.profile_zoom
                            ? `translate(${character.profile_position.x}px, ${character.profile_position.y}px) scale(${character.profile_zoom})`
                            : 'none',
                          transformOrigin: 'center center'
                        }}
                      />
                    ) : (
                      <div className="w-full h-full bg-[#1E2430] flex items-center justify-center">
                        <User className="w-8 h-8 text-gray-500" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <button
          onClick={() => setCreateDialogOpen(true)}
          className="w-full bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430] font-bold py-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Create New
        </button>
      </div>

      {/* Center - Character Portrait */}
      <div className="flex-1 flex items-center justify-center p-8 relative z-10">
        {selectedCharacter ? (
          <div
            className="w-full h-full bg-top bg-cover rounded-2xl shadow-2xl"
            style={{
              backgroundImage: `url(${selectedCharacter.avatar_url || 'https://via.placeholder.com/800x1000'})`,
              maxWidth: '600px'
            }}
          />
        ) : (
          <div className="text-gray-500 text-xl">Select a character to view</div>
        )}
      </div>

      {/* Right Panel - Character Details */}
      {selectedCharacter && (
        <div className="w-[500px] p-6 overflow-y-auto relative z-10 overflow-x-hidden" style={{
          background: 'linear-gradient(to left, rgba(30, 36, 48, 0.7), rgba(30, 36, 48, 0.95))'
        }}>
          <div className="mb-6">
            <div className="flex items-start justify-between mb-2">
              <h1 className="text-3xl font-bold text-[#FF5722] flex-1">{selectedCharacter.name}</h1>
              <div className="flex gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(createPageUrl("CharacterCreator") + `?edit=${selectedCharacter.id}`);
                  }}
                  className="p-2 bg-[#37F2D1] hover:bg-[#2dd9bd] rounded-lg transition-colors"
                  title="Edit Character"
                >
                  <Edit className="w-4 h-4 text-[#1E2430]" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setCharacterToDelete(selectedCharacter);
                    setDeleteDialogOpen(true);
                  }}
                  className="p-2 bg-[#FF5722] hover:bg-[#FF6B3D] rounded-lg transition-colors"
                  title="Delete Character"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>
            <p className="text-gray-300 text-lg mb-3">
              Level {selectedCharacter.level} {selectedCharacter.race || ''} {selectedCharacter.class}
            </p>
            {selectedCharacter.tags && selectedCharacter.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedCharacter.tags.map((tag, idx) => (
                  <Badge key={idx} variant="secondary" className="bg-[#1E2430] text-white">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            <div className="bg-[#1E2430] rounded-lg p-4 max-h-32 overflow-y-auto">
              <p className="text-gray-400 text-sm leading-relaxed">
                {selectedCharacter.description || "No biography available."}
              </p>
            </div>
          </div>

          {/* Companion Section */}
          {selectedCharacter.companion_name && (
            <div className="mb-6 bg-[#1E2430]/70 rounded-lg p-4 border border-[#5B4B9E]/30">
              <div className="flex gap-4">
                <div className="w-20 h-20 rounded-lg overflow-hidden border-2 border-[#5B4B9E]/50 flex-shrink-0">
                  {selectedCharacter.companion_image ? (
                    <img
                      src={selectedCharacter.companion_image}
                      alt={selectedCharacter.companion_name}
                      className="w-full h-full object-cover object-top"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#2A3441] flex items-center justify-center">
                      <User className="w-8 h-8 text-[#5B4B9E]" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-bold text-[#5B4B9E] mb-1">{selectedCharacter.companion_name}</h3>
                  <div className="max-h-16 overflow-y-auto">
                    <p className="text-white/70 text-sm leading-relaxed">
                      {selectedCharacter.companion_background || "No companion background available."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tabs */}
          <div className="flex gap-4 mb-6 border-b-2 border-gray-600">
            {['Stats', 'Skills', 'Spells', 'Background', 'Inventory'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab.toLowerCase())}
                className={`pb-3 px-1 font-bold text-base transition-colors ${
                  activeTab === tab.toLowerCase()
                    ? 'text-[#FF5722] border-b-4 border-[#FF5722]'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Stats Tab */}
          {activeTab === 'stats' && (
            <div className="space-y-4">
              {/* Combat Stats Row */}
              <div className="grid grid-cols-3 gap-3">
                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-[#37F2D1]/30 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('ac')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Shield className="w-5 h-5 text-[#37F2D1] mx-auto mb-1" />
                  <div className="text-xs text-gray-400 mb-1">ARMOR CLASS</div>
                  <div className="text-3xl font-bold text-white">{selectedCharacter.armor_class || 10}</div>
                  {hoveredItem === 'ac' && (
                    <div className="absolute z-20 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-[#37F2D1]">
                      {statDescriptions["Armor Class"]}
                    </div>
                  )}
                </div>

                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-[#FF5722]/30 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('initiative')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Zap className="w-5 h-5 text-[#FF5722] mx-auto mb-1" />
                  <div className="text-xs text-gray-400 mb-1">INITIATIVE</div>
                  <div className="text-3xl font-bold text-white">{calculateModifier(selectedCharacter.attributes?.dex || 10)}</div>
                  {hoveredItem === 'initiative' && (
                    <div className="absolute z-20 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-[#FF5722]">
                      {statDescriptions["Initiative"]}
                    </div>
                  )}
                </div>

                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-gray-600 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('speed')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Footprints className="w-5 h-5 text-gray-400 mx-auto mb-1" />
                  <div className="text-xs text-gray-400 mb-1">SPEED</div>
                  <div className="text-3xl font-bold text-white">{selectedCharacter.speed || 30}</div>
                  <div className="text-xs text-gray-500">ft.</div>
                  {hoveredItem === 'speed' && (
                    <div className="absolute z-20 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-gray-600">
                      {statDescriptions["Speed"]}
                    </div>
                  )}
                </div>
              </div>

              {/* HP and Hit Dice Row */}
              <div className="grid grid-cols-2 gap-3">
                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-red-500/30 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('hp')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Heart className="w-5 h-5 text-red-500 mx-auto mb-1" />
                  <div className="text-xs text-gray-400 mb-1">HIT POINTS</div>
                  <div className="text-4xl font-bold text-white">{selectedCharacter.hit_points?.max || 10}</div>
                  {hoveredItem === 'hp' && (
                    <div className="absolute z-20 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-red-500">
                      {statDescriptions["Hit Points"]}
                    </div>
                  )}
                </div>

                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-gray-600 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('hitdice')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <div className="text-xs text-gray-400 mb-1">HIT DICE</div>
                  <div className="text-4xl font-bold text-white">1d{classHitDice[selectedCharacter.class] || 8}</div>
                  {hoveredItem === 'hitdice' && (
                    <div className="absolute z-20 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-gray-600">
                      {statDescriptions["Hit Dice"]}
                    </div>
                  )}
                </div>
              </div>

              {/* Ability Scores */}
              <div className="bg-[#1E2430]/50 rounded-xl p-4 border border-gray-700">
                <h3 className="text-sm font-bold text-[#FFC6AA] mb-3 uppercase">Ability Scores</h3>
                <div className="grid grid-cols-3 gap-3">
                  {selectedCharacter.attributes && Object.entries(selectedCharacter.attributes).map(([key, value]) => {
                    const savingThrows = selectedCharacter.saving_throws || {};
                    const isProficient = savingThrows[key];
                    return (
                      <div
                        key={key}
                        className={`bg-[#2A3441] rounded-lg p-3 border ${isProficient ? 'border-yellow-400' : 'border-gray-700'} cursor-help relative`}
                        onMouseEnter={() => setHoveredItem(`ability-${key}`)}
                        onMouseLeave={() => setHoveredItem(null)}
                      >
                        <div className="text-xs text-gray-400 uppercase text-center mb-1">{key}</div>
                        <div className="text-2xl font-bold text-[#FF5722] text-center">
                          {calculateModifier(value)}
                        </div>
                        <div className="text-sm text-gray-300 text-center bg-[#1E2430] rounded-full w-10 h-10 flex items-center justify-center mx-auto mt-2">
                          {value}
                        </div>
                        {isProficient && (
                          <div className="text-center mt-2">
                            <div className="text-xs text-yellow-400 font-semibold">Save {getSavingThrowModifier(key)}</div>
                          </div>
                        )}
                        {hoveredItem === `ability-${key}` && (
                          <div className="absolute z-20 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-48 shadow-xl border-2 border-[#FF5722]">
                            <div className="font-bold mb-1">{key.toUpperCase()}</div>
                            <div>Base modifier: {calculateModifier(value)}</div>
                            {isProficient && <div className="text-yellow-400 mt-1">Proficient in saving throws</div>}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Proficiency & Perception */}
              <div className="grid grid-cols-2 gap-3">
                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-yellow-400 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('proficiency')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <div className="text-xs text-gray-400 mb-1">PROFICIENCY</div>
                  <div className="text-4xl font-bold text-yellow-400">
                    +{selectedCharacter.proficiency_bonus || 2}
                  </div>
                  {hoveredItem === 'proficiency' && (
                    <div className="absolute z-30 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-yellow-400">
                      {statDescriptions["Proficiency Bonus"]}
                    </div>
                  )}
                </div>

                <div
                  className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-xl p-4 text-center border border-gray-600 cursor-help relative"
                  onMouseEnter={() => setHoveredItem('perception')}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Eye className="w-5 h-5 text-gray-400 mx-auto mb-1" />
                  <div className="text-xs text-gray-400 mb-1">PASSIVE PERCEPTION</div>
                  <div className="text-4xl font-bold text-white">
                    {selectedCharacter.passive_perception || 10}
                  </div>
                  {hoveredItem === 'perception' && (
                    <div className="absolute z-40 left-0 bottom-full mb-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-gray-600">
                      {statDescriptions["Passive Perception"]}
                    </div>
                  )}
                </div>
              </div>

              <Button className="w-full bg-[#FF5722] hover:bg-[#FF6B3D] text-white font-bold text-xl py-6 rounded-2xl">
                PLAY
              </Button>
            </div>
          )}

          {/* Skills Tab */}
          {activeTab === 'skills' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                {allSkills.map((skillName) => {
                  const skills = selectedCharacter.skills || {};
                  const expertise = selectedCharacter.expertise || [];
                  const isProficient = skills[skillName];
                  const hasExpertise = expertise.includes(skillName);

                  const modifier = getSkillModifier(skillName);

                  return (
                    <div
                      key={skillName}
                      className="bg-gradient-to-r from-[#2A3441] to-[#1E2430] rounded-lg p-2 border border-gray-700 flex items-center gap-2 cursor-help relative transition-all hover:border-[#FF5722]"
                      onMouseEnter={() => setHoveredItem(`skill-${skillName}`)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {hasExpertise ? (
                          <div className="w-3 h-3 bg-yellow-400 rounded-sm flex items-center justify-center">
                            <span className="text-[#1E2430] text-xs font-bold">★</span>
                          </div>
                        ) : isProficient ? (
                          <div className="w-3 h-3 bg-[#37F2D1] rounded-sm flex items-center justify-center">
                            <span className="text-[#1E2430] text-xs font-bold">✓</span>
                          </div>
                        ) : (
                          <div className="w-3 h-3 border border-gray-600 rounded-sm flex-shrink-0" />
                        )}
                      </div>

                      <div className="text-xl font-bold w-11 text-center flex-shrink-0 text-white">
                        {modifier}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm truncate text-white">
                          {skillName}
                        </div>
                        <div className="text-xs text-gray-500">({skillAbilityMap[skillName]})</div>
                      </div>

                      {hoveredItem === `skill-${skillName}` && (
                        <div className="absolute z-30 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-[#37F2D1]">
                          <div className="font-bold mb-2 text-[#37F2D1]">{skillName}</div>
                          <div className="space-y-1">
                            <div>Base Ability: {skillAbilityMap[skillName]} ({calculateModifier(selectedCharacter.attributes?.[skillAbilityKeys[skillName]] || 10)})</div>
                            {isProficient && <div className="text-white">Proficiency: +{selectedCharacter.proficiency_bonus || 2}</div>}
                            {hasExpertise && <div className="text-yellow-400">Expertise: +{selectedCharacter.proficiency_bonus || 2} (×2)</div>}
                            <div className="pt-2 border-t border-gray-700">Total Modifier: <span className="text-[#37F2D1] font-bold">{modifier}</span></div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Tool Proficiencies */}
              {selectedCharacter.proficiencies?.tools && selectedCharacter.proficiencies.tools.length > 0 && (
                <div className="bg-[#1E2430]/50 rounded-xl p-4 border border-gray-700 mt-4">
                  <h3 className="text-sm font-bold text-[#FFC6AA] mb-3 uppercase">Tool Proficiencies</h3>
                  <div className="space-y-2">
                    {selectedCharacter.proficiencies.tools.map((tool, idx) => (
                      <div
                        key={idx}
                        className="relative cursor-help"
                        onMouseEnter={() => setHoveredItem(`tool-${idx}`)}
                        onMouseLeave={() => setHoveredItem(null)}
                      >
                        <div className="bg-gradient-to-r from-[#2A3441] to-[#1E2430] rounded-lg p-2 border border-[#37F2D1] flex items-center gap-2">
                          <div className="w-3 h-3 bg-[#37F2D1] rounded-sm flex items-center justify-center flex-shrink-0">
                            <span className="text-[#1E2430] text-xs font-bold">✓</span>
                          </div>
                          <div className="text-white font-semibold text-sm">{tool}</div>
                        </div>
                        {hoveredItem === `tool-${idx}` && (
                          <div className="absolute z-30 right-0 top-full mt-2 bg-[#1E2430] text-white p-3 rounded-lg text-xs w-64 shadow-xl border-2 border-[#37F2D1]">
                            <div className="font-bold mb-1 text-[#37F2D1]">{tool}</div>
                            <div>You can add your proficiency bonus (+{selectedCharacter.proficiency_bonus || 2}) when making ability checks using this tool.</div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Spells Tab */}
          {activeTab === 'spells' && (
            <div className="space-y-4">
              {selectedCharacter.spells && (selectedCharacter.spells.cantrips?.length > 0 || selectedCharacter.spells.level1?.length > 0) ? (
                <>
                  {/* Spellcasting Stats */}
                  <div className="bg-[#1E2430]/50 rounded-xl p-4 border border-gray-700">
                    <h3 className="text-sm font-bold text-[#FFC6AA] mb-3 uppercase">Spellcasting</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-lg p-3 text-center border border-[#37F2D1]/30">
                        <div className="text-xs text-gray-400 mb-1">SPELL ATTACK</div>
                        <div className="text-3xl font-bold text-[#37F2D1]">
                          {`+${(selectedCharacter.proficiency_bonus || 2) + getModifierValue(selectedCharacter.attributes?.cha || 10)}`}
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-lg p-3 text-center border border-[#FF5722]/30">
                        <div className="text-xs text-gray-400 mb-1">SPELL SAVE DC</div>
                        <div className="text-3xl font-bold text-[#FF5722]">
                          {8 + (selectedCharacter.proficiency_bonus || 2) + getModifierValue(selectedCharacter.attributes?.cha || 10)}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Cantrips */}
                  {selectedCharacter.spells.cantrips?.length > 0 && (
                    <div className="bg-[#1E2430]/50 rounded-xl p-4 border border-gray-700">
                      <h3 className="text-sm font-bold text-[#FFC6AA] mb-3 uppercase">Cantrips</h3>
                      <div className="space-y-2">
                        {selectedCharacter.spells.cantrips.map((spell, idx) => {
                          const details = spellDetails[spell];
                          return (
                            <div
                              key={idx}
                              className="bg-gradient-to-r from-[#2A3441] to-[#1E2430] rounded-lg p-3 border border-gray-700 hover:border-[#37F2D1] transition-all cursor-help relative"
                              onMouseEnter={() => setHoveredItem(`cantrip-${idx}`)}
                              onMouseLeave={() => setHoveredItem(null)}
                            >
                              <div className="font-bold text-white text-sm mb-1">{spell}</div>
                              <div className="text-xs text-gray-400">
                                {details ? `${details.school} • ${details.castingTime}` : 'Cantrip'}
                              </div>
                              {hoveredItem === `cantrip-${idx}` && details && (
                                <div className="absolute z-30 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-xs w-96 shadow-xl border-2 border-[#37F2D1] max-h-64 overflow-y-auto">
                                  <div className="font-bold mb-2 text-[#37F2D1]">{spell}</div>
                                  <div className="text-gray-400 text-xs mb-2">
                                    {details.school} cantrip • {details.castingTime}
                                  </div>
                                  <div className="space-y-1 text-xs mb-2">
                                    <div><span className="text-gray-400">Range:</span> {details.range}</div>
                                    <div><span className="text-gray-400">Components:</span> {details.components}</div>
                                    <div><span className="text-gray-400">Duration:</span> {details.duration}</div>
                                  </div>
                                  <div className="text-white whitespace-pre-wrap">{details.description}</div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* 1st Level Spells */}
                  {selectedCharacter.spells.level1?.length > 0 && (
                    <div className="bg-[#1E2430]/50 rounded-xl p-4 border border-gray-700">
                      <h3 className="text-sm font-bold text-[#FFC6AA] mb-3 uppercase">1st Level Spells</h3>
                      <div className="space-y-2">
                        {selectedCharacter.spells.level1.map((spell, idx) => {
                          const details = spellDetails[spell];
                          return (
                            <div
                              key={idx}
                              className="bg-gradient-to-r from-[#2A3441] to-[#1E2430] rounded-lg p-3 border border-gray-700 hover:border-[#FF5722] transition-all cursor-help relative"
                              onMouseEnter={() => setHoveredItem(`spell1-${idx}`)}
                              onMouseLeave={() => setHoveredItem(null)}
                            >
                              <div className="font-bold text-white text-sm mb-1">{spell}</div>
                              <div className="text-xs text-gray-400">
                                {details ? `${details.school} • ${details.castingTime}` : '1st Level'}
                              </div>
                              {hoveredItem === `spell1-${idx}` && details && (
                                <div className="absolute z-30 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-xs w-96 shadow-xl border-2 border-[#FF5722] max-h-64 overflow-y-auto">
                                  <div className="font-bold mb-2 text-[#FF5722]">{spell}</div>
                                  <div className="text-gray-400 text-xs mb-2">
                                    {details.level} {details.school} • {details.castingTime}
                                  </div>
                                  <div className="space-y-1 text-xs mb-2">
                                    <div><span className="text-gray-400">Range:</span> {details.range}</div>
                                    <div><span className="text-gray-400">Components:</span> {details.components}</div>
                                    <div><span className="text-gray-400">Duration:</span> {details.duration}</div>
                                  </div>
                                  <div className="text-white whitespace-pre-wrap">{details.description}</div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <div className="text-4xl mb-2">✨</div>
                  <p>No spells prepared</p>
                </div>
              )}
            </div>
          )}

          {/* Background Tab */}
          {activeTab === 'background' && (
            <div className="space-y-6">
              {/* Background */}
              <div>
                <h3 className="text-2xl font-bold text-[#FFC6AA] mb-3 uppercase">
                  {selectedCharacter.background || "Unknown"}
                </h3>
                <div className="space-y-2">
                  <div
                    className="relative cursor-help"
                    onMouseEnter={() => setHoveredItem('alignment')}
                    onMouseLeave={() => setHoveredItem(null)}
                  >
                    <span className="text-[#37F2D1] font-semibold">Alignment:</span>
                    <span className="text-white ml-2">{selectedCharacter.alignment}</span>
                    {hoveredItem === 'alignment' && alignmentDescriptions[selectedCharacter.alignment] && (
                      <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722]">
                        <div className="font-bold mb-2 text-[#FF5722]">{selectedCharacter.alignment}</div>
                        <div className="text-white">{alignmentDescriptions[selectedCharacter.alignment]}</div>
                      </div>
                    )}
                  </div>
                  {bgInfo && (
                    <div
                      className="relative cursor-help"
                      onMouseEnter={() => setHoveredItem('bgfeature')}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <span className="text-[#37F2D1] font-semibold">Feature:</span>
                      <span className="text-white ml-2">{bgInfo.feature}</span>
                      {hoveredItem === 'bgfeature' && (
                        <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722]">
                          <div className="font-bold mb-2 text-[#FF5722]">{bgInfo.feature}</div>
                          <div className="text-white">{bgInfo.description}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Race */}
              <div>
                <h3 className="text-2xl font-bold text-[#FFC6AA] mb-3 uppercase">Race</h3>
                <div className="space-y-2">
                  {classInfo && (
                    <>
                      <div
                        className="relative cursor-help"
                        onMouseEnter={() => setHoveredItem('creaturetype')}
                        onMouseLeave={() => setHoveredItem(null)}
                      >
                        <span className="text-[#37F2D1] font-semibold">Creature Type:</span>
                        <span className="text-white ml-2">{classInfo.creatureType}</span>
                        {hoveredItem === 'creaturetype' && (
                          <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722]">
                            <div className="font-bold mb-2 text-[#FF5722]">Humanoid</div>
                            <div className="text-white">A general term for the enormous variety of sentient species that populate the D&D world, including humans, elves, dwarves, and many others.</div>
                          </div>
                        )}
                      </div>
                      <div
                        className="relative cursor-help"
                        onMouseEnter={() => setHoveredItem('age')}
                        onMouseLeave={() => setHoveredItem(null)}
                      >
                        <span className="text-[#37F2D1] font-semibold">Age:</span>
                        <span className="text-white ml-2">{selectedCharacter.appearance?.age || 'Unknown'} years old</span>
                      </div>
                      <div
                        className="relative cursor-help"
                        onMouseEnter={() => setHoveredItem('size')}
                        onMouseLeave={() => setHoveredItem(null)}
                      >
                        <span className="text-[#37F2D1] font-semibold">Size:</span>
                        <span className="text-white ml-2">{classInfo.size}</span>
                        {hoveredItem === 'size' && (
                          <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722]">
                            <div className="font-bold mb-2 text-[#FF5722]">{classInfo.size}</div>
                            <div className="text-white">Creatures of different sizes occupy different amounts of space. Medium creatures occupy a 5-foot-by-5-foot space. Small creatures also occupy 5 feet but can move through the space of larger creatures.</div>
                          </div>
                        )}
                      </div>
                      {classInfo.features.map((feature, idx) => (
                        <div
                          key={idx}
                          className="relative cursor-help"
                          onMouseEnter={() => setHoveredItem(`racefeature-${idx}`)}
                          onMouseLeave={() => setHoveredItem(null)}
                        >
                          <span className="text-[#37F2D1] font-semibold">{feature}</span>
                          {hoveredItem === `racefeature-${idx}` && featureDescriptions[feature] && (
                            <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722] max-h-64 overflow-y-auto">
                              <div className="font-bold mb-2 text-[#FF5722]">{feature}</div>
                              <div className="text-white">{featureDescriptions[feature]}</div>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>

              {/* Class */}
              <div>
                <h3 className="text-2xl font-bold text-[#FFC6AA] mb-3 uppercase">Class</h3>
                <div className="space-y-2">
                  {selectedCharacter.feature_choices && Object.entries(selectedCharacter.feature_choices).map(([key, value], idx) => {
                    const description = subclassDescriptions[value] || pactBoonDescriptions[value] || fightingStyleDescriptions[value];

                    return (
                      <div
                        key={idx}
                        className="relative cursor-help"
                        onMouseEnter={() => setHoveredItem(`classchoice-${idx}`)}
                        onMouseLeave={() => setHoveredItem(null)}
                      >
                        <span className="text-[#37F2D1] font-semibold">{value}</span>
                        {hoveredItem === `classchoice-${idx}` && description && (
                          <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722] max-h-64 overflow-y-auto">
                            <div className="font-bold mb-2 text-[#FF5722]">{value}</div>
                            <div className="text-white">{description}</div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {classFeatureNames[selectedCharacter.class]?.map((feature, idx) => (
                    <div
                      key={idx}
                      className="relative cursor-help"
                      onMouseEnter={() => setHoveredItem(`classfeature-${idx}`)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <span className="text-[#37F2D1] font-semibold">{feature}</span>
                      {hoveredItem === `classfeature-${idx}` && classFeatureDescriptions[feature] && (
                        <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722] max-h-64 overflow-y-auto">
                          <div className="font-bold mb-2 text-[#FF5722]">{feature}</div>
                          <div className="text-white">{classFeatureDescriptions[feature]}</div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Eldritch Invocations */}
              {selectedCharacter.class === "Warlock" && selectedCharacter.feature_choices && (
                <div>
                  <h3 className="text-2xl font-bold text-[#FFC6AA] mb-3 uppercase">Eldritch Invocations</h3>
                  <div className="space-y-2">
                    {Object.entries(selectedCharacter.feature_choices)
                      .filter(([key]) => key.includes('Eldritch Invocation'))
                      .map(([key, invocation], idx) => (
                        <div
                          key={idx}
                          className="relative cursor-help"
                          onMouseEnter={() => setHoveredItem(`invocation-${idx}`)}
                          onMouseLeave={() => setHoveredItem(null)}
                        >
                          <span className="text-[#37F2D1] font-semibold">{invocation}</span>
                          {hoveredItem === `invocation-${idx}` && invocationDescriptions[invocation] && (
                            <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722] max-h-64 overflow-y-auto">
                              <div className="font-bold mb-2 text-[#FF5722]">{invocation}</div>
                              <div className="text-white">{invocationDescriptions[invocation]}</div>
                            </div>
                          )}
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* Languages */}
              <div>
                <h3 className="text-2xl font-bold text-[#FFC6AA] mb-3 uppercase">Languages</h3>
                <div className="space-y-2">
                  {(selectedCharacter.languages || []).map((lang, idx) => (
                    <div
                      key={idx}
                      className="relative cursor-help"
                      onMouseEnter={() => setHoveredItem(`language-${idx}`)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <span className="text-[#37F2D1] font-semibold">{lang}</span>
                      {hoveredItem === `language-${idx}` && languageDescriptions[lang] && (
                        <div className="absolute z-20 left-0 top-full mt-2 bg-[#1E2430] text-white p-4 rounded-lg text-sm w-96 shadow-xl border-2 border-[#FF5722]">
                          <div className="font-bold mb-2 text-[#FF5722]">{lang}</div>
                          <div className="text-white">{languageDescriptions[lang]}</div>
                        </div>
                      )}
                    </div>
                  ))}
                  {(!selectedCharacter.languages || selectedCharacter.languages.length === 0) && (
                    <span className="text-gray-400">No languages selected</span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Inventory Tab */}
          {activeTab === 'inventory' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-[#FFC6AA] font-semibold text-lg mb-3 flex items-center gap-2">
                  <Swords className="w-5 h-5" />
                  Equipment & Gear
                </h3>
                {selectedCharacter.inventory && selectedCharacter.inventory.length > 0 ? (
                  <div className="space-y-2">
                    {selectedCharacter.inventory.map((item, idx) => (
                      <div key={idx} className="bg-gradient-to-r from-[#2A3441] to-[#1E2430] rounded-lg p-3 border border-gray-700 hover:border-[#37F2D1] transition-all">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <p className="text-white font-semibold">{item.name}</p>
                            {item.description && (
                              <p className="text-gray-400 text-sm mt-1">{item.description}</p>
                            )}
                          </div>
                          <div className="text-right ml-3">
                            {item.quantity > 1 && (
                              <p className="text-[#37F2D1] font-bold text-lg">×{item.quantity}</p>
                            )}
                            {item.weight && (
                              <p className="text-gray-500 text-xs">{item.weight} lb</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <div className="text-4xl mb-2">🎒</div>
                    <p>No items in inventory</p>
                  </div>
                )}
              </div>

              <div>
                <h3 className="text-[#FFC6AA] font-semibold text-lg mb-3">Currency</h3>
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { key: 'cp', name: 'Copper', color: 'text-orange-700' },
                    { key: 'sp', name: 'Silver', color: 'text-gray-400' },
                    { key: 'ep', name: 'Electrum', color: 'text-emerald-400' },
                    { key: 'gp', name: 'Gold', color: 'text-yellow-400' },
                    { key: 'pp', name: 'Platinum', color: 'text-cyan-300' }
                  ].map(({ key, name, color }) => (
                    <div
                      key={key}
                      className="bg-gradient-to-br from-[#2A3441] to-[#1E2430] rounded-lg p-3 text-center border border-gray-700 cursor-help relative"
                      onMouseEnter={() => setHoveredItem(`currency-${key}`)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <div className={`text-2xl font-bold ${color}`}>
                        {selectedCharacter.currency?.[key] || 0}
                      </div>
                      <div className="text-xs text-gray-500 uppercase mt-1">{key}</div>
                      {hoveredItem === `currency-${key}` && (
                        <div className="absolute z-20 left-1/2 -translate-x-1/2 top-full mt-2 bg-[#1E2430] text-white p-2 rounded-lg text-xs whitespace-nowrap shadow-xl border-2 border-gray-600">
                          {name} Pieces
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <CreateCharacterDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-[#2A3441] border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-300">
              This will permanently delete <span className="font-bold text-[#FF5722]">{characterToDelete?.name}</span>.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-gray-600 text-white hover:bg-gray-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteCharacterMutation.mutate(characterToDelete?.id)}
              className="bg-[#FF5722] hover:bg-[#FF6B3D] text-white"
            >
              Delete Character
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
