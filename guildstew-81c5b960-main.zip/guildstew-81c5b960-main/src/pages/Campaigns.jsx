import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import CampaignGrid from "@/components/campaigns/CampaignGrid";

export default function Campaigns() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    initialData: null
  });

  const { data: campaigns } = useQuery({
    queryKey: ['allCampaigns'],
    queryFn: async () => {
      const allCampaigns = await base44.entities.Campaign.list('-updated_date');
      return allCampaigns.filter(c => 
        c.game_master_id === user?.id || c.player_ids?.includes(user?.id)
      );
    },
    enabled: !!user,
    initialData: []
  });

  const { data: conversations } = useQuery({
    queryKey: ['allConversations'],
    queryFn: () => base44.entities.ChatConversation.list(),
    enabled: !!user,
    initialData: []
  });

  useEffect(() => {
    const ensureCampaignChats = async () => {
      if (!campaigns.length || !user) return;

      const activeCampaigns = campaigns.filter(c => c.status === 'active');
      
      for (const campaign of activeCampaigns) {
        const existingChat = conversations.find(
          c => c.campaign_id === campaign.id && c.type === 'campaign_group'
        );

        if (!existingChat) {
          const participantIds = [
            campaign.game_master_id,
            ...(campaign.player_ids || [])
          ].filter((id, index, self) => id && self.indexOf(id) === index);

          await base44.entities.ChatConversation.create({
            name: campaign.title,
            type: 'campaign_group',
            participant_ids: participantIds,
            campaign_id: campaign.id,
            last_message: 'Campaign chat created',
            last_message_at: new Date().toISOString()
          });
        }
      }

      queryClient.invalidateQueries({ queryKey: ['allConversations'] });
    };

    ensureCampaignChats();
  }, [campaigns, conversations, user]);

  const createSampleCampaigns = useMutation({
    mutationFn: async () => {
      const samples = [
        {
          title: "The Cursed Isles",
          description: "A dark fantasy campaign set on mysterious cursed islands",
          cover_image_url: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&h=800&fit=crop",
          system: "D&D 5e",
          status: "active",
          session_count: 12,
          total_hours: 48,
          consent_rating: "orange",
          world_lore: "The Cursed Isles were once prosperous kingdoms, now shrouded in eternal mist and plagued by undead horrors.",
          homebrew_rules: "Death saves use d12 instead of d20. Critical hits on 19-20.",
          game_master_id: user.id
        },
        {
          title: "Starlight Academy",
          description: "A magical school adventure full of mystery and wonder",
          cover_image_url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&h=800&fit=crop",
          system: "D&D 5e",
          status: "active",
          session_count: 8,
          total_hours: 32,
          consent_rating: "yellow",
          world_lore: "Starlight Academy trains the brightest magical minds from across the realm.",
          npcs_image_url: "https://images.unsplash.com/photo-1618641986557-1ecd230959aa?w=800&h=600&fit=crop",
          maps_image_url: "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&h=600&fit=crop",
          game_master_id: user.id
        },
        {
          title: "Shadows Over Waterdeep",
          description: "Urban intrigue and mystery in the City of Splendors",
          cover_image_url: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1200&h=800&fit=crop",
          system: "D&D 5e",
          status: "archived",
          session_count: 24,
          total_hours: 96,
          consent_rating: "orange",
          world_lore: "Waterdeep, the Crown of the North, hides dark secrets beneath its shining towers.",
          items_image_url: "https://images.unsplash.com/photo-1595433707802-6b2626ef1c91?w=800&h=600&fit=crop",
          world_lore_image_url: "https://images.unsplash.com/photo-1515705576963-95cad62945b6?w=800&h=600&fit=crop",
          homebrew_image_url: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&h=600&fit=crop",
          game_master_id: user.id
        },
        {
          title: "Frontier Legends",
          description: "Wild west meets fantasy in this unique campaign",
          cover_image_url: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=1200&h=800&fit=crop",
          system: "Pathfinder 2e",
          status: "archived",
          session_count: 16,
          total_hours: 64,
          consent_rating: "yellow",
          game_master_id: user.id
        }
      ];
      
      for (const campaign of samples) {
        await base44.entities.Campaign.create(campaign);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allCampaigns'] });
    }
  });

  const activeCampaigns = campaigns.filter(c => c.status === 'active');
  const archivedCampaigns = campaigns.filter(c => c.status === 'archived');
  const gmCampaigns = campaigns.filter(c => c.game_master_id === user?.id);

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold">Your Campaigns</h1>
          {campaigns.length === 0 && (
            <Button
              onClick={() => createSampleCampaigns.mutate()}
              disabled={createSampleCampaigns.isPending}
              className="bg-[#37F2D1] hover:bg-[#2dd9bd] text-[#1E2430]"
            >
              {createSampleCampaigns.isPending ? 'Creating...' : 'Create Sample Campaigns'}
            </Button>
          )}
        </div>

        <Tabs defaultValue="active" className="space-y-6">
          <TabsList className="bg-[#2A3441]">
            <TabsTrigger value="active" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              Active
            </TabsTrigger>
            <TabsTrigger value="archived" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              Archived
            </TabsTrigger>
            <TabsTrigger value="gm" className="data-[state=active]:bg-[#37F2D1] data-[state=active]:text-[#1E2430]">
              As Game Master
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active">
            <CampaignGrid campaigns={activeCampaigns} />
          </TabsContent>

          <TabsContent value="archived">
            <CampaignGrid campaigns={archivedCampaigns} grayscale />
          </TabsContent>

          <TabsContent value="gm">
            <CampaignGrid campaigns={gmCampaigns} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}